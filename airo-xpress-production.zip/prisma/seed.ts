import { PrismaClient, UserRole } from "@prisma/client";
import bcrypt from "bcryptjs";
import { deliveryTiers } from "../lib/locations";

const db = new PrismaClient();
const categories = [
  ["Electronics", "electronics"],
  ["Fashion", "fashion"],
  ["Home & Kitchen", "home-kitchen"],
  ["Beauty & Personal Care", "beauty"],
  ["Sports", "sports"],
  ["Grocery", "grocery"],
  ["Accessories", "accessories"],
  ["Other", "other"]
];

async function main() {
  for (const [name, slug] of categories) {
    await db.category.upsert({ where: { slug }, update: { name }, create: { name, slug } });
  }
  for (const tier of deliveryTiers) {
    await db.deliveryZone.upsert({
      where: { cityPattern: tier.cityPattern },
      update: { name: tier.name, fee: tier.defaultFee, isActive: true },
      create: { name: tier.name, cityPattern: tier.cityPattern, fee: tier.defaultFee }
    });
  }
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (email && password) {
    if (password.length < 14) throw new Error("ADMIN_PASSWORD must contain at least 14 characters.");
    const passwordHash = await bcrypt.hash(password, 12);
    await db.user.upsert({
      where: { email },
      update: { role: UserRole.ADMIN, passwordHash },
      create: { name: "AIRO Administrator", email, passwordHash, role: UserRole.ADMIN }
    });
    console.info(`Administrator account configured for ${email}.`);
  } else {
    console.info("No administrator created. Set ADMIN_EMAIL and ADMIN_PASSWORD to bootstrap one.");
  }
  console.info("Categories are ready. No sample products were created.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}).finally(async () => db.$disconnect());
