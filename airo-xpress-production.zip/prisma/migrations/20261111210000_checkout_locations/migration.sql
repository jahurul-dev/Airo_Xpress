CREATE TYPE "DeliveryTier" AS ENUM ('INSIDE_DHAKA', 'SUBURBAN_DHAKA', 'OUTSIDE_DHAKA');

ALTER TABLE "Address"
  ADD COLUMN "district" TEXT NOT NULL DEFAULT '',
  ADD COLUMN "upazila" TEXT NOT NULL DEFAULT '',
  ADD COLUMN "deliveryInstructions" TEXT;

ALTER TABLE "Order"
  ADD COLUMN "checkoutRequestId" TEXT,
  ADD COLUMN "deliveryTier" "DeliveryTier" NOT NULL DEFAULT 'OUTSIDE_DHAKA',
  ADD COLUMN "couponCode" TEXT;

ALTER TABLE "OrderItem"
  ADD COLUMN "productImage" TEXT;

ALTER TABLE "ProductImage"
  ADD COLUMN "publicId" TEXT;

CREATE UNIQUE INDEX "Order_checkoutRequestId_key" ON "Order"("checkoutRequestId");

CREATE TABLE "Banner" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT,
  "imageUrl" TEXT,
  "linkUrl" TEXT,
  "position" INTEGER NOT NULL DEFAULT 0,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Banner_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "Banner_isActive_position_idx" ON "Banner"("isActive", "position");
