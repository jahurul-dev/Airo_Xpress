"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { trackMetaEvent, trackPurchaseOnce } from "@/lib/meta-pixel";

type Cart = {
  items: { productId: string; quantity: number; product: { name: string; price: string | number } }[];
};
type Location = { name: string; nameBn: string; upazilas: { name: string; nameBn: string }[] };
type DeliveryOption = { type: "INSIDE_DHAKA" | "SUBURBAN_DHAKA" | "OUTSIDE_DHAKA"; name: string; fee: number; configured: boolean };

const money = (amount: number) => `৳${amount.toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function CheckoutPage() {
  const [cart, setCart] = useState<Cart | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [deliveryOptions, setDeliveryOptions] = useState<DeliveryOption[]>([]);
  const [district, setDistrict] = useState("");
  const [upazila, setUpazila] = useState("");
  const [deliveryTier, setDeliveryTier] = useState<DeliveryOption["type"]>("OUTSIDE_DHAKA");
  const [couponCode, setCouponCode] = useState("");
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponMessage, setCouponMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const requestId = useRef("");
  const checkoutTracked = useRef(false);
  const router = useRouter();

  useEffect(() => {
    Promise.all([
      fetch("/api/cart").then(async (response) => {
        const data = await response.json();
        if (response.status === 401) {
          window.location.href = "/login?next=/checkout";
          return null;
        }
        if (!response.ok) throw new Error(data.error ?? "Could not load cart");
        return data.cart as Cart | null;
      }),
      fetch("/data/bangladesh-locations.json").then(async (response) => {
        if (!response.ok) throw new Error("Bangladesh location data could not be loaded.");
        const data = await response.json();
        return data.districts as Location[];
      }),
      fetch("/api/delivery-zones").then(async (response) => {
        if (!response.ok) throw new Error("Delivery fees could not be loaded.");
        const data = await response.json();
        return data.options as DeliveryOption[];
      })
    ]).then(([cartData, locationData, deliveryData]) => {
      if (cartData) setCart(cartData);
      setLocations(locationData);
      setDeliveryOptions(deliveryData);
    }).catch((reason: Error) => setError(reason.message))
      .finally(() => setLoading(false));
  }, []);

  const selectedDistrict = locations.find((item) => item.name === district);
  const selectedDelivery = deliveryOptions.find((item) => item.type === deliveryTier);
  const subtotal = useMemo(
    () => (cart?.items ?? []).reduce((sum, item) => sum + Math.round(Number(item.product.price) * 100) * item.quantity, 0) / 100,
    [cart]
  );
  const total = Math.max(0, subtotal - couponDiscount + (selectedDelivery?.fee ?? 0));

  useEffect(() => {
    if (!cart?.items.length || checkoutTracked.current) return;
    checkoutTracked.current = true;
    trackMetaEvent("InitiateCheckout", {
      content_ids: cart.items.map((item) => item.productId),
      contents: cart.items.map((item) => ({ id: item.productId, quantity: item.quantity })),
      content_type: "product",
      currency: "BDT",
      value: subtotal
    });
  }, [cart, subtotal]);

  function changeDistrict(value: string) {
    setDistrict(value);
    setUpazila("");
    setCouponDiscount(0);
    setCouponMessage("");
    if (value === "Dhaka" && deliveryTier === "OUTSIDE_DHAKA") setDeliveryTier("INSIDE_DHAKA");
    else if (value !== "Dhaka" && deliveryTier !== "OUTSIDE_DHAKA") setDeliveryTier("OUTSIDE_DHAKA");
  }

  async function validateCoupon() {
    setCouponMessage("");
    setCouponDiscount(0);
    if (!couponCode.trim()) {
      setCouponMessage("Enter a coupon code first.");
      return;
    }
    const response = await fetch("/api/coupons/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ couponCode, deliveryTier })
    });
    const data = await response.json();
    if (!response.ok) {
      setCouponMessage(data.error ?? "Coupon could not be applied.");
      return;
    }
    setCouponDiscount(Number(data.discount));
    setCouponMessage(`Coupon ${data.couponCode} applied.`);
  }

  async function placeOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = new FormData(event.currentTarget);
    const payload = {
      checkoutRequestId: requestId.current || (requestId.current = crypto.randomUUID()),
      address: {
        recipient: form.get("recipient"),
        phone: form.get("phone"),
        district,
        upazila,
        addressLine: form.get("addressLine"),
        deliveryInstructions: form.get("deliveryInstructions") || undefined,
        postalCode: form.get("postalCode") || undefined
      },
      deliveryTier,
      paymentMethod: form.get("paymentMethod"),
      couponCode: couponCode.trim() || undefined
    };
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Could not place order");
      trackPurchaseOnce(data.order.orderNumber, {
        content_ids: data.order.items.map((item: { productId: string }) => item.productId),
        contents: data.order.items.map((item: { productId: string; quantity: number; unitPrice: string | number }) => ({
          id: item.productId,
          quantity: item.quantity,
          item_price: Number(item.unitPrice)
        })),
        content_type: "product",
        currency: "BDT",
        value: Number(data.order.total)
      });
      router.push(`/account/orders?placed=${encodeURIComponent(data.order.orderNumber)}`);
      router.refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not place order");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="container page-loading">Loading checkout…</div>;

  return <div className="container content-page">
    <div className="page-title"><span className="eyebrow">ONE LAST THING</span><h1>Checkout</h1></div>
    {!cart?.items.length ? <div className="empty-state"><h3>Your cart is empty</h3><Link href="/shop" className="button button-primary">Explore the shop</Link></div> :
      <form className="checkout-grid" onSubmit={placeOrder}>
        <section className="account-panel">
          <h2>Delivery details / ডেলিভারির তথ্য</h2>
          <div className="form-field"><label htmlFor="recipient">Customer full name / সম্পূর্ণ নাম</label><input id="recipient" name="recipient" autoComplete="name" required minLength={2} maxLength={100} /></div>
          <div className="form-field"><label htmlFor="phone">Mobile number / মোবাইল নম্বর</label><input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="01XXXXXXXXX or +8801XXXXXXXXX" required pattern="(?:\+?8801|01)[3-9][0-9]{8}" title="Enter a valid Bangladesh mobile number, e.g. 01712345678" /></div>
          <div className="form-field"><label htmlFor="district">District / জেলা</label><select id="district" value={district} onChange={(event) => changeDistrict(event.target.value)} required><option value="">Select district / জেলা নির্বাচন করুন</option>{locations.map((item) => <option key={item.name} value={item.name}>{item.name}{item.nameBn ? ` — ${item.nameBn}` : ""}</option>)}</select></div>
          <div className="form-field"><label htmlFor="upazila">Upazila / Thana / উপজেলা / থানা</label><select id="upazila" value={upazila} onChange={(event) => setUpazila(event.target.value)} required disabled={!selectedDistrict}><option value="">Select upazila / থানা নির্বাচন করুন</option>{selectedDistrict?.upazilas.map((item) => <option key={item.name} value={item.name}>{item.name}{item.nameBn ? ` — ${item.nameBn}` : ""}</option>)}</select></div>
          <div className="form-field"><label htmlFor="addressLine">Full address / সম্পূর্ণ ঠিকানা</label><textarea id="addressLine" name="addressLine" autoComplete="street-address" placeholder="House, road, village and landmark" required minLength={5} maxLength={250} /></div>
          <div className="form-field"><label htmlFor="deliveryInstructions">Additional delivery instructions (optional)</label><textarea id="deliveryInstructions" name="deliveryInstructions" maxLength={500} placeholder="Landmark, preferred delivery time, or other instructions" /></div>
          <div className="form-field"><label htmlFor="postalCode">Postal code (optional)</label><input id="postalCode" name="postalCode" autoComplete="postal-code" maxLength={20} /></div>

          <h2>Delivery option / ডেলিভারি চার্জ</h2>
          <div className="delivery-options">{deliveryOptions.map((option) => <label className={`delivery-option ${deliveryTier === option.type ? "is-selected" : ""}`} key={option.type}>
            <input type="radio" name="deliveryTierOption" value={option.type} checked={deliveryTier === option.type} onChange={() => { setDeliveryTier(option.type); setCouponDiscount(0); setCouponMessage(""); }} />
            <span><b>{option.name}</b><small>{option.type === "INSIDE_DHAKA" ? "ঢাকার ভেতরে" : option.type === "SUBURBAN_DHAKA" ? "ঢাকার আশেপাশে" : "ঢাকার বাইরে"}</small></span>
            <strong>{money(option.fee)}</strong>
          </label>)}</div>
          <p className="muted-copy">Delivery charges are verified again on the server when your order is placed.</p>

          <h2>Payment method</h2>
          <div className="form-field"><label htmlFor="paymentMethod">Choose how to pay</label><select id="paymentMethod" name="paymentMethod" defaultValue="COD"><option value="COD">Cash on delivery</option><option value="BKASH">bKash (merchant integration required)</option><option value="NAGAD">Nagad (merchant integration required)</option><option value="CARD">Visa / Mastercard (gateway integration required)</option></select></div>
          <p className="muted-copy">Online payments remain unavailable until official merchant credentials and verified gateway callbacks are configured. No payment is simulated.</p>
        </section>

        <aside className="summary-card">
          <h2>Your order</h2>
          {cart.items.map((item) => <div className="summary-row" key={item.productId}><span>{item.product.name} × {item.quantity}</span><b>{money(Number(item.product.price) * item.quantity)}</b></div>)}
          <div className="coupon-entry"><label className="sr-only" htmlFor="couponCode">Coupon code</label><input id="couponCode" value={couponCode} onChange={(event) => { setCouponCode(event.target.value); setCouponDiscount(0); setCouponMessage(""); }} placeholder="Coupon code" maxLength={40} /><button type="button" className="button button-outline" onClick={validateCoupon}>Apply</button></div>
          {couponMessage && <small className={couponDiscount > 0 ? "coupon-success" : "coupon-error"}>{couponMessage}</small>}
          <div className="summary-row"><span>Product subtotal</span><b>{money(subtotal)}</b></div>
          <div className="summary-row"><span>Coupon discount</span><b>−{money(couponDiscount)}</b></div>
          <div className="summary-row"><span>Delivery ({selectedDelivery?.name ?? "Select option"})</span><b>{money(selectedDelivery?.fee ?? 0)}</b></div>
          <div className="summary-row summary-total"><span>Total payable</span><b>{money(total)}</b></div>
          {error && <div className="notice notice-error">{error}</div>}
          <button className="button button-primary" disabled={busy || !selectedDistrict || !upazila || !selectedDelivery?.configured}>{busy ? "Placing order…" : "Place order"} <span>→</span></button>
        </aside>
      </form>}
  </div>;
}
