import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { MetaPixel } from "@/components/MetaPixel";
import { getAppUrl } from "@/lib/app-url";

export const metadata: Metadata = {
  metadataBase: new URL(getAppUrl()),
  title: { default: "AIRO XPRESS | Everyday finds, delivered", template: "%s | AIRO XPRESS" },
  description: "Shop trusted finds across electronics, fashion, home, beauty and more at AIRO XPRESS.",
  applicationName: "AIRO XPRESS",
  robots: { index: true, follow: true },
  openGraph: {
    type: "website",
    siteName: "AIRO XPRESS",
    title: "AIRO XPRESS | Everyday finds, delivered",
    description: "Shop trusted finds across electronics, fashion, home, beauty and more at AIRO XPRESS.",
    url: getAppUrl()
  },
  twitter: {
    card: "summary",
    title: "AIRO XPRESS | Everyday finds, delivered",
    description: "Shop trusted finds across electronics, fashion, home, beauty and more at AIRO XPRESS."
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <MetaPixel />
        <div className="announcement">Fast delivery across Bangladesh <span>•</span> Easy, secure checkout</div>
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
