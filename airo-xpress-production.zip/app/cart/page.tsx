"use client";

import Link from "next/link";
import Image from "next/image";
import { FormEvent, useEffect, useMemo, useState } from "react";

type Cart = { items: { productId: string; quantity: number; product: { id: string; name: string; slug: string; price: string | number; stock: number; images: { url: string }[] } }[] };

export default function CartPage() {
  const [cart, setCart] = useState<Cart | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [couponMessage, setCouponMessage] = useState("");

  async function loadCart() {
    const response = await fetch("/api/cart");
    const data = await response.json();
    if (response.status === 401) { window.location.href = "/login?next=/cart"; return; }
    if (!response.ok) throw new Error(data.error ?? "Could not load cart");
    setCart(data.cart ?? { items: [] });
  }
  useEffect(() => {
    loadCart().catch((reason: Error) => setError(reason.message)).finally(() => setBusy(false));
  }, []);

  const subtotal = useMemo(() => cart?.items.reduce((sum, item) => sum + Number(item.product.price) * item.quantity, 0) ?? 0, [cart]);

  async function update(productId: string, quantity: number) {
    const response = await fetch("/api/cart", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, quantity })
    });
    const data = await response.json();
    if (!response.ok) { setError(data.error ?? "Could not update cart"); return; }
    await loadCart();
  }

  async function applyCoupon(event: FormEvent) {
    event.preventDefault();
    setCouponMessage("Coupon discounts are validated securely at checkout.");
    setDiscount(0);
  }

  return <div className="container content-page">
    <div className="page-title"><span className="eyebrow">YOUR GOOD FINDS</span><h1>Your cart</h1></div>
    {error && <div className="notice notice-error">{error}</div>}
    {busy ? <p className="muted-copy">Loading your cart…</p> : !cart?.items.length ?
      <div className="empty-state"><span>▢</span><h3>Your cart is waiting for something good</h3><p>Browse the collection and add your favourites.</p><Link className="button button-primary" href="/shop">Explore the shop <span>→</span></Link></div> :
      <div className="cart-layout">
        <div className="cart-items">{cart.items.map((item) => <div className="cart-line" key={item.productId}>
          <Link className="cart-thumb" href={`/product/${item.product.slug}`}>{item.product.images[0]?.url ? <Image src={item.product.images[0].url} alt="" width={75} height={75} unoptimized /> : <span>AX</span>}</Link>
          <div><h3><Link href={`/product/${item.product.slug}`}>{item.product.name}</Link></h3><p>৳{Number(item.product.price).toLocaleString("en-BD")} each</p><input aria-label={`Quantity for ${item.product.name}`} type="number" min={0} max={item.product.stock} value={item.quantity} onChange={(event) => update(item.productId, Number(event.target.value))} /></div>
          <div><b>৳{(Number(item.product.price) * item.quantity).toLocaleString("en-BD")}</b><br /><button className="remove-button" onClick={() => update(item.productId, 0)}>Remove</button></div>
        </div>)}</div>
        <aside className="summary-card"><h2>Order summary</h2><div className="summary-row"><span>Subtotal</span><span>৳{subtotal.toLocaleString("en-BD")}</span></div><div className="summary-row"><span>Delivery</span><span>Calculated at checkout</span></div>
          <form className="promo-code" onSubmit={applyCoupon}><label className="sr-only" htmlFor="coupon">Coupon code</label><input id="coupon" value={couponCode} onChange={(event) => setCouponCode(event.target.value)} placeholder="Have a coupon?" /><button>Apply</button></form>{couponMessage && <small className="muted-copy">{couponMessage}</small>}
          <div className="summary-row summary-total"><span>Estimated total</span><span>৳{(subtotal - discount).toLocaleString("en-BD")}</span></div><Link href="/checkout" className="button button-primary">Continue to checkout <span>→</span></Link><small className="muted-copy">Taxes and delivery are confirmed before placing your order.</small>
        </aside>
      </div>}
  </div>;
}
