import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container content-page">
      <div className="page-title">
        <span className="eyebrow">NOT THE RIGHT PAGE</span>
        <h1>We couldn’t find that.</h1>
      </div>
      <div className="empty-state">
        <span>404</span>
        <h3>This page may have moved or no longer exists.</h3>
        <p>Head back to AIRO XPRESS or browse the current collection.</p>
        <Link className="button button-primary" href="/">Back to home</Link>{" "}
        <Link className="button button-outline" href="/shop">Explore the shop</Link>
      </div>
    </div>
  );
}
