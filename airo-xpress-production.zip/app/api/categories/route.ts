import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const categories = await db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, slug: true, imageUrl: true } });
  return NextResponse.json({ categories });
}
