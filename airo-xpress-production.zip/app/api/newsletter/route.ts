import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { clientRateLimitKey, enforceRateLimit, errorResponse, requireSameOrigin } from "@/lib/http";

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    if (!(await enforceRateLimit(clientRateLimitKey(request, "newsletter"), 5, 60 * 60 * 1000))) {
      return NextResponse.json({ error: "Too many signup attempts. Try again later." }, { status: 429 });
    }
    const { email } = z.object({ email: z.string().email().max(254).transform((value) => value.toLowerCase()) }).parse(await request.json());
    await db.newsletterSubscriber.upsert({ where: { email }, create: { email }, update: {} });
    return NextResponse.json({ message: "Thanks for joining the AIRO XPRESS good list." }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
