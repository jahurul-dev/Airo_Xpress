import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";
import { isValidDistrictUpazila } from "@/lib/locations";

const schema = z.object({
  label: z.string().trim().max(40).optional(),
  recipient: z.string().trim().min(2).max(100),
  phone: z.string().trim().min(8).max(20),
  addressLine: z.string().trim().min(5).max(250),
  area: z.string().trim().min(2).max(100),
  city: z.string().trim().min(2).max(100),
  district: z.string().trim().min(2).max(80),
  upazila: z.string().trim().min(2).max(100),
  deliveryInstructions: z.string().trim().max(500).optional(),
  postalCode: z.string().trim().max(20).optional(),
  isDefault: z.boolean().default(false)
});

export async function GET() {
  try {
    const user = await requireUser();
    const addresses = await db.address.findMany({ where: { userId: user.id }, orderBy: [{ isDefault: "desc" }, { createdAt: "desc" }] });
    return NextResponse.json({ addresses });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = schema.parse(await request.json());
    if (!isValidDistrictUpazila(body.district, body.upazila)) {
      return NextResponse.json({ error: "Select a valid district and upazila." }, { status: 400 });
    }
    const address = await db.$transaction(async (tx) => {
      if (body.isDefault) await tx.address.updateMany({ where: { userId: user.id }, data: { isDefault: false } });
      return tx.address.create({ data: { ...body, userId: user.id, label: body.label || "Home" } });
    });
    return NextResponse.json({ address }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
