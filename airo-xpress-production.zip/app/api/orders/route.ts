import { NextResponse } from "next/server";
import { OrderStatus, PaymentMethod, PaymentStatus, Prisma } from "@prisma/client";
import { z } from "zod";
import { randomUUID } from "node:crypto";
import { requireUser } from "@/lib/auth";
import { calculateCouponDiscount, couponIsAvailable, fromMinorUnits, toMinorUnits } from "@/lib/checkout";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";
import { deliveryTiers, isValidDistrictUpazila } from "@/lib/locations";
import { getPaymentGateway, PaymentUnavailableError } from "@/lib/payments";
import { sendMetaPurchaseConversion } from "@/lib/meta-conversions";

export const maxDuration = 30;

const schema = z.object({
  checkoutRequestId: z.string().uuid(),
  address: z.object({
    recipient: z.string().trim().min(2).max(100),
    phone: z.string().trim().regex(/^(?:\+?8801|01)[3-9]\d{8}$/, "Enter a valid Bangladesh mobile number"),
    addressLine: z.string().trim().min(5).max(250),
    district: z.string().trim().min(2).max(80),
    upazila: z.string().trim().min(2).max(100),
    deliveryInstructions: z.string().trim().max(500).optional(),
    postalCode: z.string().trim().max(20).optional()
  }),
  deliveryTier: z.enum(["INSIDE_DHAKA", "SUBURBAN_DHAKA", "OUTSIDE_DHAKA"]),
  paymentMethod: z.nativeEnum(PaymentMethod),
  couponCode: z.string().trim().max(40).optional()
});

export async function GET() {
  try {
    const user = await requireUser();
    const orders = await db.order.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      include: { items: true, payment: true, shipment: true }
    });
    return NextResponse.json({ orders });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request) {
  let checkoutUserId: string | null = null;
  let checkoutRequestId: string | null = null;
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    checkoutUserId = user.id;
    const body = schema.parse(await request.json());
    checkoutRequestId = body.checkoutRequestId;
    if (!isValidDistrictUpazila(body.address.district, body.address.upazila)) {
      return NextResponse.json({ error: "Select a valid district and upazila." }, { status: 400 });
    }
    const existing = await db.order.findFirst({
      where: { checkoutRequestId: body.checkoutRequestId, userId: user.id },
      include: { items: true }
    });
    if (existing) {
      await sendMetaPurchaseConversion(existing, user.email, existing.deliveryAddress);
      return NextResponse.json({ order: existing }, { status: 200 });
    }
    if (body.paymentMethod !== PaymentMethod.COD) {
      try {
        getPaymentGateway(body.paymentMethod);
      } catch (error) {
        if (error instanceof PaymentUnavailableError) {
          return NextResponse.json({ error: error.message }, { status: 503 });
        }
        throw error;
      }
    }

    const result = await db.$transaction(async (tx) => {
      const cart = await tx.cart.findUnique({
        where: { userId: user.id },
        include: { items: { include: { product: { include: { images: { orderBy: { position: "asc" }, take: 1 } } } } } }
      });
      if (!cart?.items.length) throw new CheckoutError("Your cart is empty");
      for (const item of cart.items) {
        if (!item.product.isActive || item.quantity > item.product.stock) {
          throw new CheckoutError(`${item.product.name} is no longer available in the requested quantity`);
        }
      }

      const subtotalMinor = cart.items.reduce((sum, item) => sum + toMinorUnits(item.product.price) * item.quantity, 0);
      let discountMinor = 0;
      let couponCode: string | null = null;
      if (body.couponCode) {
        const coupon = await tx.coupon.findUnique({ where: { code: body.couponCode.toUpperCase() } });
        if (!couponIsAvailable(coupon, subtotalMinor)) {
          throw new CheckoutError("Coupon is invalid or unavailable");
        }
        discountMinor = calculateCouponDiscount(coupon, subtotalMinor);
        couponCode = coupon.code;
        const couponUpdate = await tx.coupon.updateMany({
          where: { id: coupon.id, isActive: true, ...(coupon.maxUses !== null ? { uses: { lt: coupon.maxUses } } : {}) },
          data: { uses: { increment: 1 } }
        });
        if (couponUpdate.count !== 1) throw new CheckoutError("Coupon is no longer available.");
      }
      const tier = deliveryTiers.find((item) => item.code === body.deliveryTier);
      if (!tier) throw new CheckoutError("Select a valid delivery option.");
      const zone = await tx.deliveryZone.findFirst({ where: { isActive: true, cityPattern: tier.cityPattern } });
      if (!zone) throw new CheckoutError("Delivery fees are not configured. Please contact support.");
      const deliveryFeeMinor = toMinorUnits(zone.fee);
      const totalMinor = Math.max(0, subtotalMinor + deliveryFeeMinor - discountMinor);
      const addressData = { ...body.address, deliveryTier: tier.code };
      const order = await tx.order.create({
        data: {
          orderNumber: `AX-${Date.now().toString(36).toUpperCase()}-${randomUUID().slice(0, 5).toUpperCase()}`,
          checkoutRequestId: body.checkoutRequestId,
          userId: user.id,
          deliveryTier: tier.code,
          couponCode,
          deliveryAddress: addressData,
          status: OrderStatus.PENDING,
          paymentMethod: body.paymentMethod,
          subtotal: new Prisma.Decimal(fromMinorUnits(subtotalMinor).toFixed(2)),
          deliveryFee: new Prisma.Decimal(fromMinorUnits(deliveryFeeMinor).toFixed(2)),
          discount: new Prisma.Decimal(fromMinorUnits(discountMinor).toFixed(2)),
          total: new Prisma.Decimal(fromMinorUnits(totalMinor).toFixed(2)),
          items: { create: cart.items.map((item) => ({
            productId: item.productId, productName: item.product.name,
            productImage: item.product.images[0]?.url ?? null,
            unitPrice: item.product.price, quantity: item.quantity
          })) },
          payment: { create: { method: body.paymentMethod, amount: new Prisma.Decimal(fromMinorUnits(totalMinor).toFixed(2)), status: PaymentStatus.PENDING } }
        },
        include: { items: true }
      });
      for (const item of cart.items) {
        const changed = await tx.product.updateMany({
          where: { id: item.productId, stock: { gte: item.quantity } },
          data: { stock: { decrement: item.quantity } }
        });
        if (changed.count !== 1) throw new CheckoutError(`${item.product.name} just sold out; please try again`);
      }
      await tx.cartItem.deleteMany({ where: { cartId: cart.id } });
      return order;
    }, {
      isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      maxWait: 10_000,
      timeout: 20_000
    });
    await sendMetaPurchaseConversion(result, user.email, result.deliveryAddress);
    return NextResponse.json({ order: result }, { status: 201 });
  } catch (error) {
    if (error instanceof CheckoutError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    if (error instanceof Prisma.PrismaClientKnownRequestError &&
      (error.code === "P2002" || error.code === "P2034")) {
      if (checkoutRequestId && checkoutUserId) {
        const existing = await db.order.findFirst({
          where: { checkoutRequestId, userId: checkoutUserId },
          include: { items: true }
        });
        if (existing) {
          const user = await db.user.findUnique({ where: { id: checkoutUserId }, select: { email: true } });
          await sendMetaPurchaseConversion(existing, user?.email ?? null, existing.deliveryAddress);
          return NextResponse.json({ order: existing }, { status: 200 });
        }
      }
      return NextResponse.json({ error: "Checkout conflicted with another request. Please retry." }, { status: 409 });
    }
    return errorResponse(error);
  }
}

class CheckoutError extends Error {}
