import { createHash, createHmac } from "node:crypto";
import { NextResponse } from "next/server";
import { UserRole, VendorStatus } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";
import { getImageDeletionPublicId } from "@/lib/uploads";

export const runtime = "nodejs";
const MAX_FILE_SIZE = 5 * 1024 * 1024;
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    if (user.role !== UserRole.ADMIN && user.role !== UserRole.VENDOR) {
      return NextResponse.json({ error: "Only approved sellers and administrators can upload images" }, { status: 403 });
    }
    if (user.role === UserRole.VENDOR) {
      const vendor = await db.vendor.findUnique({ where: { userId: user.id }, select: { status: true } });
      if (!vendor || vendor.status !== VendorStatus.APPROVED) return NextResponse.json({ error: "Vendor account is not approved" }, { status: 403 });
    }
    const cloud = process.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;
    if (!cloud || !apiKey || !apiSecret) return NextResponse.json({ error: "Image uploads are unavailable: Cloudinary credentials are not configured" }, { status: 503 });

    const formData = await request.formData();
    const file = formData.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "An image file is required" }, { status: 400 });
    if (!allowedTypes.has(file.type)) return NextResponse.json({ error: "Use a JPEG, PNG, or WebP image" }, { status: 400 });
    if (file.size < 1 || file.size > MAX_FILE_SIZE) return NextResponse.json({ error: "Image must be no larger than 5 MB" }, { status: 400 });
    const bytes = new Uint8Array(await file.slice(0, 12).arrayBuffer());
    const validContent =
      (file.type === "image/jpeg" && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) ||
      (file.type === "image/png" && bytes.slice(0, 8).join(",") === "137,80,78,71,13,10,26,10") ||
      (file.type === "image/webp" && new TextDecoder().decode(bytes.slice(0, 4)) === "RIFF" && new TextDecoder().decode(bytes.slice(8, 12)) === "WEBP");
    if (!validContent) return NextResponse.json({ error: "Image content does not match the selected file type" }, { status: 400 });
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const signature = createHmac("sha1", apiSecret).update(`timestamp=${timestamp}`).digest("hex");
    const payload = new FormData();
    payload.append("file", file);
    payload.append("api_key", apiKey);
    payload.append("timestamp", timestamp);
    payload.append("signature", signature);
    const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/image/upload`, { method: "POST", body: payload });
    const result = await response.json() as { secure_url?: string; public_id?: string; error?: { message?: string } };
    if (!response.ok || !result.secure_url) {
      console.error("Cloudinary upload failed", { status: response.status, providerMessage: result.error?.message });
      return NextResponse.json({ error: "Image provider rejected the upload" }, { status: 502 });
    }
    return NextResponse.json({ url: result.secure_url, publicId: result.public_id });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = await request.json() as { imageId?: unknown; publicId?: unknown };
    if ((typeof body.imageId !== "string" || !body.imageId) &&
      (typeof body.publicId !== "string" || !body.publicId)) {
      return NextResponse.json({ error: "imageId or publicId is required" }, { status: 400 });
    }
    const image = typeof body.imageId === "string" && body.imageId
      ? await db.productImage.findUnique({
        where: { id: body.imageId },
        include: { product: { select: { vendorId: true } } }
      })
      : null;
    if (body.imageId && !image) return NextResponse.json({ error: "Product image not found" }, { status: 404 });
    if (user.role !== UserRole.ADMIN) {
      if (user.role !== UserRole.VENDOR) return NextResponse.json({ error: "Not authorized" }, { status: 403 });
      if (!image) return NextResponse.json({ error: "Only administrators can delete unattached images" }, { status: 403 });
      const vendor = await db.vendor.findUnique({ where: { userId: user.id }, select: { id: true, status: true } });
      if (!vendor || vendor.status !== VendorStatus.APPROVED || image.product.vendorId !== vendor.id) {
        return NextResponse.json({ error: "Not authorized to remove this image" }, { status: 403 });
      }
    }
    const publicId = getImageDeletionPublicId(user.role, image?.publicId, body.publicId);
    if (publicId) {
      const cloud = process.env.CLOUDINARY_CLOUD_NAME;
      const apiKey = process.env.CLOUDINARY_API_KEY;
      const apiSecret = process.env.CLOUDINARY_API_SECRET;
      if (!cloud || !apiKey || !apiSecret) {
        return NextResponse.json({ error: "Cloudinary credentials are required to delete this image" }, { status: 503 });
      }
      const timestamp = Math.floor(Date.now() / 1000).toString();
      const signature = createHash("sha1").update(`public_id=${publicId}&timestamp=${timestamp}${apiSecret}`).digest("hex");
      const payload = new FormData();
      payload.append("public_id", publicId);
      payload.append("api_key", apiKey);
      payload.append("timestamp", timestamp);
      payload.append("signature", signature);
      const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/image/destroy`, { method: "POST", body: payload });
      const result = await response.json() as { result?: string; error?: { message?: string } };
      if (!response.ok || (result.result !== "ok" && result.result !== "not found")) {
        console.error("Cloudinary image deletion failed", { status: response.status, providerMessage: result.error?.message });
        return NextResponse.json({ error: "Image provider could not delete this image" }, { status: 502 });
      }
    }
    if (image) await db.productImage.delete({ where: { id: image.id } });
    return NextResponse.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
