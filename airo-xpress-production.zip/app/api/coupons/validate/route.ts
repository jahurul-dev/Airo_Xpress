import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { calculateCouponDiscount, couponIsAvailable, fromMinorUnits, toMinorUnits } from "@/lib/checkout";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";
import { deliveryTiers } from "@/lib/locations";

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = z.object({
      couponCode: z.string().trim().min(1).max(40),
      deliveryTier: z.enum(["INSIDE_DHAKA", "SUBURBAN_DHAKA", "OUTSIDE_DHAKA"])
    }).parse(await request.json());
    const cart = await db.cart.findUnique({
      where: { userId: user.id },
      include: { items: { include: { product: { select: { price: true, isActive: true } } } } }
    });
    if (!cart?.items.length || cart.items.some((item) => !item.product.isActive)) {
      return NextResponse.json({ error: "Your cart is empty or contains an unavailable product." }, { status: 400 });
    }
    const subtotalMinor = cart.items.reduce((sum, item) => sum + toMinorUnits(item.product.price) * item.quantity, 0);
    const coupon = await db.coupon.findUnique({ where: { code: body.couponCode.toUpperCase() } });
    if (!couponIsAvailable(coupon, subtotalMinor)) {
      return NextResponse.json({ error: "Coupon is invalid or unavailable." }, { status: 400 });
    }
    const tier = deliveryTiers.find((item) => item.code === body.deliveryTier);
    if (!tier) return NextResponse.json({ error: "Select a valid delivery option." }, { status: 400 });
    const zone = await db.deliveryZone.findFirst({ where: { isActive: true, cityPattern: tier.cityPattern } });
    if (!zone) return NextResponse.json({ error: "Delivery fees are not configured. Please contact support." }, { status: 503 });
    const discount = calculateCouponDiscount(coupon, subtotalMinor);
    return NextResponse.json({
      couponCode: coupon.code,
      subtotal: fromMinorUnits(subtotalMinor),
      discount: fromMinorUnits(discount),
      deliveryFee: Number(zone.fee),
      total: fromMinorUnits(subtotalMinor - discount + toMinorUnits(zone.fee))
    });
  } catch (error) {
    return errorResponse(error);
  }
}
