import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

const cartSchema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1).max(20)
});

export async function GET() {
  try {
    const user = await requireUser();
    const cart = await db.cart.findUnique({
      where: { userId: user.id },
      include: { items: { include: { product: { include: { images: { orderBy: { position: "asc" }, take: 1 } } } } } }
    });
    return NextResponse.json({ cart });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = cartSchema.parse(await request.json());
    const product = await db.product.findFirst({ where: { id: body.productId, isActive: true } });
    if (!product) return NextResponse.json({ error: "Product not found" }, { status: 404 });
    const cart = await db.cart.upsert({ where: { userId: user.id }, create: { userId: user.id }, update: {} });
    const current = await db.cartItem.findUnique({ where: { cartId_productId: { cartId: cart.id, productId: product.id } } });
    const quantity = (current?.quantity ?? 0) + body.quantity;
    if (quantity > product.stock) return NextResponse.json({ error: "Requested quantity exceeds available stock" }, { status: 409 });
    await db.cartItem.upsert({
      where: { cartId_productId: { cartId: cart.id, productId: product.id } },
      create: { cartId: cart.id, productId: product.id, quantity: body.quantity },
      update: { quantity }
    });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function PATCH(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = cartSchema.extend({ quantity: z.number().int().min(0).max(20) }).parse(await request.json());
    const cart = await db.cart.findUnique({ where: { userId: user.id } });
    if (!cart) return NextResponse.json({ error: "Cart not found" }, { status: 404 });
    if (body.quantity === 0) {
      await db.cartItem.deleteMany({ where: { cartId: cart.id, productId: body.productId } });
    } else {
      const item = await db.cartItem.findUnique({
        where: { cartId_productId: { cartId: cart.id, productId: body.productId } },
        include: { product: true }
      });
      if (!item) return NextResponse.json({ error: "Cart item not found" }, { status: 404 });
      if (body.quantity > item.product.stock) return NextResponse.json({ error: "Requested quantity exceeds available stock" }, { status: 409 });
      await db.cartItem.update({ where: { id: item.id }, data: { quantity: body.quantity } });
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}

export async function DELETE(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const productId = new URL(request.url).searchParams.get("productId");
    if (!productId) return NextResponse.json({ error: "productId is required" }, { status: 400 });
    await db.cartItem.deleteMany({ where: { cart: { userId: user.id }, productId } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
