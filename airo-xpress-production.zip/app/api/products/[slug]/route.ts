import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { jsonError } from "@/lib/http";

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await db.product.findFirst({
    where: { slug, isActive: true },
    include: {
      images: { orderBy: { position: "asc" } },
      category: { select: { name: true, slug: true } },
      reviews: { orderBy: { createdAt: "desc" }, take: 20, include: { user: { select: { name: true } } } }
    }
  });
  if (!product) return jsonError("Product not found", 404);
  return NextResponse.json({ product });
}
