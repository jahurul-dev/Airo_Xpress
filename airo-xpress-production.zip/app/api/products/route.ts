import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";

const querySchema = z.object({
  q: z.string().trim().max(100).optional(),
  category: z.string().trim().max(80).optional(),
  min: z.coerce.number().min(0).optional(),
  max: z.coerce.number().min(0).optional(),
  sort: z.enum(["newest", "price_asc", "price_desc", "popular"]).default("newest"),
  page: z.coerce.number().int().min(1).max(10000).default(1)
});

export async function GET(request: Request) {
  try {
    const params = querySchema.parse(Object.fromEntries(new URL(request.url).searchParams));
    const where: Prisma.ProductWhereInput = {
      isActive: true,
      ...(params.q ? { OR: [
        { name: { contains: params.q, mode: "insensitive" } },
        { description: { contains: params.q, mode: "insensitive" } },
        { brand: { contains: params.q, mode: "insensitive" } }
      ] } : {}),
      ...(params.category ? { category: { slug: params.category } } : {}),
      ...(params.min !== undefined || params.max !== undefined ? { price: {
        ...(params.min !== undefined ? { gte: params.min } : {}),
        ...(params.max !== undefined ? { lte: params.max } : {})
      } } : {})
    };
    const orderBy: Prisma.ProductOrderByWithRelationInput =
      params.sort === "price_asc" ? { price: "asc" } :
      params.sort === "price_desc" ? { price: "desc" } :
      params.sort === "popular" ? { reviewCount: "desc" } : { createdAt: "desc" };
    const [products, total] = await db.$transaction([
      db.product.findMany({
        where, orderBy, skip: (params.page - 1) * 24, take: 24,
        include: { images: { orderBy: { position: "asc" }, take: 1 }, category: { select: { name: true, slug: true } } }
      }),
      db.product.count({ where })
    ]);
    return NextResponse.json({
      products,
      pagination: { page: params.page, pageSize: 24, total, pages: Math.ceil(total / 24) }
    });
  } catch (error) {
    return errorResponse(error);
  }
}
