import { createHash, randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { OrderStatus, PaymentMethod, PaymentStatus, Prisma } from "@prisma/client";
import { z } from "zod";
import { fromMinorUnits, toMinorUnits } from "@/lib/checkout";
import { db } from "@/lib/db";
import { clientRateLimitKey, enforceRateLimit, errorResponse, requireSameOrigin } from "@/lib/http";
import { deliveryTiers, isValidDistrictUpazila } from "@/lib/locations";
import { sendMetaPurchaseConversion } from "@/lib/meta-conversions";

export const maxDuration = 30;

const schema = z.object({
  checkoutRequestId: z.string().uuid(),
  productId: z.string().min(1).max(64),
  quantity: z.number().int().min(1).max(20),
  address: z.object({
    recipient: z.string().trim().min(2).max(100),
    phone: z.string().trim().regex(/^(?:\+?8801|01)[3-9]\d{8}$/, "Enter a valid Bangladesh mobile number"),
    addressLine: z.string().trim().min(5).max(250),
    district: z.string().trim().min(2).max(80),
    upazila: z.string().trim().min(2).max(100),
    deliveryInstructions: z.string().trim().max(500).optional(),
    postalCode: z.string().trim().max(20).optional()
  }),
  deliveryTier: z.enum(["INSIDE_DHAKA", "SUBURBAN_DHAKA", "OUTSIDE_DHAKA"])
});

export async function POST(request: Request) {
  let checkoutRequestId: string | null = null;
  try {
    requireSameOrigin(request);
    const body = schema.parse(await request.json());
    checkoutRequestId = body.checkoutRequestId;
    if (!isValidDistrictUpazila(body.address.district, body.address.upazila)) {
      return NextResponse.json({ error: "Select a valid district and upazila." }, { status: 400 });
    }

    const ipAllowed = await enforceRateLimit(clientRateLimitKey(request, "guest-order"), 5, 60 * 60 * 1000);
    const phoneKey = createHash("sha256").update(body.address.phone.replace(/\D/g, "")).digest("hex");
    const phoneAllowed = await enforceRateLimit(`guest-order-phone:${phoneKey}`, 3, 60 * 60 * 1000);
    if (!ipAllowed || !phoneAllowed) {
      return NextResponse.json({ error: "Too many order attempts. Please try again later." }, { status: 429 });
    }

    const existing = await db.order.findFirst({
      where: { checkoutRequestId, userId: null },
      include: { items: true }
    });
    if (existing) {
      const product = await db.product.findUnique({
        where: { id: existing.items[0]?.productId ?? "" },
        select: { slug: true }
      });
      await sendMetaPurchaseConversion(existing, null, existing.deliveryAddress,
        product ? `/product/${encodeURIComponent(product.slug)}` : "/");
      return NextResponse.json({ order: existing }, { status: 200 });
    }

    const result = await db.$transaction(async (tx) => {
      const product = await tx.product.findFirst({
        where: { id: body.productId, isActive: true },
        include: { images: { orderBy: { position: "asc" }, take: 1 } }
      });
      if (!product || product.stock < body.quantity) {
        throw new GuestOrderError("This product is no longer available in the requested quantity.");
      }

      const tier = deliveryTiers.find((item) => item.code === body.deliveryTier);
      if (!tier) throw new GuestOrderError("Select a valid delivery option.");
      const zone = await tx.deliveryZone.findFirst({
        where: { isActive: true, cityPattern: tier.cityPattern }
      });
      if (!zone) throw new GuestOrderError("Delivery fees are not configured. Please contact support.");

      const subtotalMinor = toMinorUnits(product.price) * body.quantity;
      const deliveryFeeMinor = toMinorUnits(zone.fee);
      const totalMinor = subtotalMinor + deliveryFeeMinor;
      const order = await tx.order.create({
        data: {
          orderNumber: `AX-${Date.now().toString(36).toUpperCase()}-${randomUUID().slice(0, 5).toUpperCase()}`,
          checkoutRequestId,
          userId: null,
          deliveryTier: tier.code,
          deliveryAddress: { ...body.address, deliveryTier: tier.code },
          status: OrderStatus.PENDING,
          paymentMethod: PaymentMethod.COD,
          subtotal: new Prisma.Decimal(fromMinorUnits(subtotalMinor).toFixed(2)),
          deliveryFee: new Prisma.Decimal(fromMinorUnits(deliveryFeeMinor).toFixed(2)),
          discount: new Prisma.Decimal("0.00"),
          total: new Prisma.Decimal(fromMinorUnits(totalMinor).toFixed(2)),
          items: {
            create: {
              productId: product.id,
              productName: product.name,
              productImage: product.images[0]?.url ?? null,
              unitPrice: product.price,
              quantity: body.quantity
            }
          },
          payment: {
            create: {
              method: PaymentMethod.COD,
              amount: new Prisma.Decimal(fromMinorUnits(totalMinor).toFixed(2)),
              status: PaymentStatus.PENDING
            }
          }
        },
        include: { items: true }
      });

      const changed = await tx.product.updateMany({
        where: { id: product.id, stock: { gte: body.quantity }, isActive: true },
        data: { stock: { decrement: body.quantity } }
      });
      if (changed.count !== 1) {
        throw new GuestOrderError("This product just sold out; please try again.");
      }
      return { order, productSlug: product.slug };
    }, {
      isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      maxWait: 10_000,
      timeout: 20_000
    });

    await sendMetaPurchaseConversion(
      result.order,
      null,
      result.order.deliveryAddress,
      `/product/${encodeURIComponent(result.productSlug)}`
    );
    return NextResponse.json({ order: result.order }, { status: 201 });
  } catch (error) {
    if (error instanceof GuestOrderError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    if (error instanceof Prisma.PrismaClientKnownRequestError &&
      (error.code === "P2002" || error.code === "P2034")) {
      if (checkoutRequestId) {
        const existing = await db.order.findFirst({
          where: { checkoutRequestId, userId: null },
          include: { items: true }
        });
        if (existing) {
          const product = await db.product.findUnique({
            where: { id: existing.items[0]?.productId ?? "" },
            select: { slug: true }
          });
          await sendMetaPurchaseConversion(existing, null, existing.deliveryAddress,
            product ? `/product/${encodeURIComponent(product.slug)}` : "/");
          return NextResponse.json({ order: existing }, { status: 200 });
        }
      }
      return NextResponse.json({ error: "Checkout conflicted with another request. Please retry." }, { status: 409 });
    }
    return errorResponse(error);
  }
}

class GuestOrderError extends Error {}
