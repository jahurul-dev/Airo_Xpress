import { NextResponse } from "next/server";
import { OrderStatus, UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { ApiError, errorResponse, requireSameOrigin } from "@/lib/http";
import { getOrderCustomer } from "@/lib/order-customer";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const order = await db.order.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, name: true, email: true, phone: true } },
        items: true,
        payment: true,
        shipment: true
      }
    });
    if (!order) throw new ApiError("Order not found", 404);
    return NextResponse.json({
      order: { ...order, customer: getOrderCustomer(order.user, order.deliveryAddress) }
    });
  } catch (error) { return errorResponse(error); }
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const { status } = z.object({ status: z.nativeEnum(OrderStatus) }).parse(await request.json());
    const result = await db.$transaction(async (tx) => {
      const current = await tx.order.findUnique({
        where: { id },
        include: { items: true, user: { select: { name: true, email: true, phone: true } } }
      });
      if (!current) throw new ApiError("Order not found", 404);
      if (current.status === OrderStatus.CANCELLED || current.status === OrderStatus.REFUNDED) {
        throw new ApiError("A cancelled or refunded order cannot be updated", 409);
      }
      if (status === OrderStatus.CANCELLED) {
        if (current.status === OrderStatus.SHIPPED || current.status === OrderStatus.DELIVERED) {
          throw new ApiError("Shipped or delivered orders cannot be cancelled. Use the return/refund workflow.", 409);
        }
        for (const item of current.items) {
          await tx.product.update({ where: { id: item.productId }, data: { stock: { increment: item.quantity } } });
        }
      }
      const updated = await tx.order.update({ where: { id: current.id }, data: { status } });
      if (current.userId) {
        await tx.notification.create({
          data: {
            userId: current.userId,
            title: `Order ${current.orderNumber} updated`,
            message: `Your order status is now ${status.toLowerCase().replaceAll("_", " ")}.`
          }
        });
      }
      if (status === OrderStatus.SHIPPED || status === OrderStatus.DELIVERED) {
        await tx.shipment.upsert({
          where: { orderId: current.id }, create: { orderId: current.id, ...(status === OrderStatus.DELIVERED ? { deliveredAt: new Date() } : {}) },
          update: status === OrderStatus.DELIVERED ? { deliveredAt: new Date() } : {}
        });
      }
      return updated;
    });
    return NextResponse.json({ order: result });
  } catch (error) { return errorResponse(error); }
}
