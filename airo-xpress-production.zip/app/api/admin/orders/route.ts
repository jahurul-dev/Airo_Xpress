import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";
import { getOrderCustomer } from "@/lib/order-customer";

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const rows = await db.order.findMany({
      orderBy: { createdAt: "desc" }, take: 200,
      include: { user: { select: { name: true, email: true, phone: true } }, items: true }
    });
    const orders = rows.map((order) => ({
      ...order,
      customer: getOrderCustomer(order.user, order.deliveryAddress)
    }));
    return NextResponse.json({ orders });
  } catch (error) { return errorResponse(error); }
}
