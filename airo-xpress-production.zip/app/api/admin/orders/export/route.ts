import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";
import { UserRole } from "@prisma/client";
import { csvCell } from "@/lib/csv";
import { getOrderCustomer } from "@/lib/order-customer";

export async function GET(request: Request) {
  try {
    await requireUser(UserRole.ADMIN);
    const params = new URL(request.url).searchParams;
    const filter = z.object({
      from: z.string().date().optional(),
      to: z.string().date().optional()
    }).parse(Object.fromEntries(params));
    const orders = await db.order.findMany({
      where: {
        ...(filter.from || filter.to ? { createdAt: {
          ...(filter.from ? { gte: new Date(`${filter.from}T00:00:00.000Z`) } : {}),
          ...(filter.to ? { lte: new Date(`${filter.to}T23:59:59.999Z`) } : {})
        } } : {})
      },
      orderBy: { createdAt: "desc" },
      take: 10000,
      include: { user: { select: { name: true, email: true, phone: true } }, items: true }
    });
    const header = ["Order Number", "Date", "Customer", "Email", "Phone", "District", "Upazila", "Address", "Items", "Subtotal", "Coupon", "Discount", "Delivery Tier", "Delivery Fee", "Total", "Payment", "Status"];
    const rows = orders.map((order) => {
      const address = order.deliveryAddress as { district?: string; upazila?: string; addressLine?: string; phone?: string };
      const customer = getOrderCustomer(order.user, order.deliveryAddress);
      return [
        order.orderNumber, order.createdAt.toISOString(), customer.name, customer.email,
        customer.phone ?? address.phone ?? "", address.district, address.upazila, address.addressLine,
        order.items.map((item) => `${item.productName} x${item.quantity}`).join("; "),
        order.subtotal, order.couponCode, order.discount, order.deliveryTier, order.deliveryFee,
        order.total, order.paymentMethod, order.status
      ].map(csvCell).join(",");
    });
    const csv = [header.map(csvCell).join(","), ...rows].join("\r\n");
    return new NextResponse(`\uFEFF${csv}`, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="airo-xpress-orders.csv"',
        "Cache-Control": "private, no-store"
      }
    });
  } catch (error) { return errorResponse(error); }
}
