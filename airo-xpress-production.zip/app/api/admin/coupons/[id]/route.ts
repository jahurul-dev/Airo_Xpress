import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const body = z.object({ isActive: z.boolean() }).parse(await request.json());
    const coupon = await db.coupon.update({ where: { id }, data: { isActive: body.isActive } });
    return NextResponse.json({ coupon });
  } catch (error) { return errorResponse(error); }
}
