import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

const couponSchema = z.object({
  code: z.string().trim().min(3).max(40).regex(/^[A-Za-z0-9_-]+$/).transform((value) => value.toUpperCase()),
  percentOff: z.number().int().min(1).max(100).optional(),
  amountOff: z.number().positive().optional(),
  minSubtotal: z.number().min(0).default(0),
  expiresAt: z.string().datetime().optional(),
  maxUses: z.number().int().positive().optional()
}).refine((value) => Number(value.percentOff !== undefined) + Number(value.amountOff !== undefined) === 1, {
  message: "Set exactly one of percentOff or amountOff"
});

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const coupons = await db.coupon.findMany({ orderBy: { createdAt: "desc" } });
    return NextResponse.json({ coupons });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = couponSchema.parse(await request.json());
    const coupon = await db.coupon.create({
      data: {
        code: body.code,
        percentOff: body.percentOff,
        amountOff: body.amountOff,
        minSubtotal: body.minSubtotal,
        expiresAt: body.expiresAt ? new Date(body.expiresAt) : null,
        maxUses: body.maxUses ?? null
      }
    });
    return NextResponse.json({ coupon }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
