import { NextResponse } from "next/server";
import { Prisma, UserRole } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const [totalSales, totalOrders, customers, products, pendingOrders, completedOrders, recentOrders, dailySales, monthlySales, topProducts] = await Promise.all([
      db.order.aggregate({ where: { status: "DELIVERED" }, _sum: { total: true } }),
      db.order.count(),
      db.user.count({ where: { role: UserRole.CUSTOMER } }),
      db.product.count(),
      db.order.count({ where: { status: "PENDING" } }),
      db.order.count({ where: { status: "DELIVERED" } }),
      db.order.findMany({ take: 10, orderBy: { createdAt: "desc" }, select: { orderNumber: true, total: true, status: true, createdAt: true } }),
      db.$queryRaw<{ period: Date; revenue: Prisma.Decimal; orders: bigint }[]>(Prisma.sql`
        SELECT date_trunc('day', "createdAt") AS period, SUM("total") AS revenue, COUNT(*) AS orders
        FROM "Order"
        WHERE "status" = 'DELIVERED'::"OrderStatus" AND "createdAt" >= NOW() - INTERVAL '30 days'
        GROUP BY period ORDER BY period
      `),
      db.$queryRaw<{ period: Date; revenue: Prisma.Decimal; orders: bigint }[]>(Prisma.sql`
        SELECT date_trunc('month', "createdAt") AS period, SUM("total") AS revenue, COUNT(*) AS orders
        FROM "Order"
        WHERE "status" = 'DELIVERED'::"OrderStatus" AND "createdAt" >= NOW() - INTERVAL '12 months'
        GROUP BY period ORDER BY period
      `),
      db.orderItem.groupBy({
        by: ["productName"],
        where: { order: { status: "DELIVERED" } },
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: "desc" } },
        take: 5
      })
    ]);
    return NextResponse.json({
      metrics: {
        revenue: Number(totalSales._sum.total ?? 0),
        orders: totalOrders,
        customers,
        products,
        pendingOrders,
        completedOrders
      },
      recentOrders,
      dailySales: dailySales.map((row) => ({ period: row.period, revenue: Number(row.revenue), orders: Number(row.orders) })),
      monthlySales: monthlySales.map((row) => ({ period: row.period, revenue: Number(row.revenue), orders: Number(row.orders) })),
      topProducts: topProducts.map((row) => ({ name: row.productName, quantity: row._sum.quantity ?? 0 }))
    });
  } catch (error) {
    return errorResponse(error);
  }
}
