import { NextResponse } from "next/server";
import { Prisma, UserRole } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";
import { getMetaConversionsStatus } from "@/lib/meta-conversions";

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const sales = await db.$queryRaw<{
      productId: string;
      productName: string;
      orderCount: bigint;
      unitCount: bigint;
      deliveredOrderCount: bigint;
      deliveredUnitCount: bigint;
      deliveredRevenue: Prisma.Decimal;
    }[]>(Prisma.sql`
      SELECT
        item."productId" AS "productId",
        item."productName" AS "productName",
        COUNT(DISTINCT item."orderId") AS "orderCount",
        COALESCE(SUM(item."quantity"), 0) AS "unitCount",
        COUNT(DISTINCT item."orderId") FILTER (WHERE order_row."status" = 'DELIVERED') AS "deliveredOrderCount",
        COALESCE(SUM(item."quantity") FILTER (WHERE order_row."status" = 'DELIVERED'), 0) AS "deliveredUnitCount",
        COALESCE(SUM(item."unitPrice" * item."quantity") FILTER (WHERE order_row."status" = 'DELIVERED'), 0) AS "deliveredRevenue"
      FROM "OrderItem" AS item
      INNER JOIN "Order" AS order_row ON order_row."id" = item."orderId"
      GROUP BY item."productId", item."productName"
      ORDER BY "deliveredRevenue" DESC, "orderCount" DESC
    `);

    return NextResponse.json({
      tracking: getMetaConversionsStatus(),
      productSales: sales.map((item) => ({
        productId: item.productId,
        productName: item.productName,
        orderCount: Number(item.orderCount),
        unitCount: Number(item.unitCount),
        deliveredOrderCount: Number(item.deliveredOrderCount),
        deliveredUnitCount: Number(item.deliveredUnitCount),
        deliveredRevenue: Number(item.deliveredRevenue)
      }))
    });
  } catch (error) {
    return errorResponse(error);
  }
}
