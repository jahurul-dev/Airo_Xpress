import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin, slugify } from "@/lib/http";

const schema = z.object({
  name: z.string().trim().min(2).max(180),
  description: z.string().trim().min(10).max(10000),
  categoryId: z.string().min(1),
  price: z.number().positive(),
  compareAtPrice: z.number().positive().optional(),
  stock: z.number().int().min(0),
  brand: z.string().trim().max(100).optional(),
  images: z.array(z.object({
    url: z.string().url(),
    publicId: z.string().max(300).optional(),
    alt: z.string().max(180).optional()
  })).max(8).default([])
});

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = schema.parse(await request.json());
    const baseSlug = slugify(body.name);
    const slug = `${baseSlug}-${crypto.randomUUID().slice(0, 8)}`;
    const product = await db.product.create({
      data: {
        name: body.name, slug, description: body.description, categoryId: body.categoryId,
        price: body.price, compareAtPrice: body.compareAtPrice, stock: body.stock, brand: body.brand,
        ...(body.images.length ? { images: { create: body.images.map((image, position) => ({ ...image, alt: image.alt ?? body.name, position })) } } : {})
      },
      include: { images: true }
    });
    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
