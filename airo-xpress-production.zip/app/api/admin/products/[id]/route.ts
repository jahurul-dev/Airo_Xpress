import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const body = z.object({
      name: z.string().trim().min(2).max(180).optional(),
      description: z.string().trim().min(10).max(10000).optional(),
      price: z.number().positive().optional(),
      compareAtPrice: z.number().positive().nullable().optional(),
      stock: z.number().int().min(0).optional(),
      isActive: z.boolean().optional(),
      categoryId: z.string().min(1).optional(),
      brand: z.string().trim().max(100).nullable().optional(),
      images: z.array(z.object({
        url: z.string().url(),
        publicId: z.string().max(300).nullable().optional(),
        alt: z.string().max(180).optional()
      })).max(8).optional()
    }).refine((value) => Object.keys(value).length > 0).parse(await request.json());
    const { images, ...productData } = body;
    const product = await db.$transaction(async (tx) => {
      await tx.product.update({ where: { id }, data: productData });
      if (images) {
        await tx.productImage.deleteMany({ where: { productId: id } });
        await tx.productImage.createMany({
          data: images.map((image, position) => ({
            productId: id,
            url: image.url,
            publicId: image.publicId ?? null,
            alt: image.alt ?? body.name ?? "Product image",
            position
          }))
        });
      }
      return tx.product.findUniqueOrThrow({ where: { id }, include: { images: { orderBy: { position: "asc" } } } });
    });
    return NextResponse.json({ product });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const product = await db.product.findUnique({
      where: { id },
      include: { images: { select: { publicId: true } }, _count: { select: { orderItems: true } } }
    });
    if (!product) return NextResponse.json({ error: "Product not found" }, { status: 404 });
    if (product._count.orderItems > 0) {
      await db.product.update({ where: { id }, data: { isActive: false } });
      return NextResponse.json({ ok: true, archived: true });
    }

    const publicIds = product.images.flatMap((image) => image.publicId ? [image.publicId] : []);
    if (publicIds.length) {
      const cloud = process.env.CLOUDINARY_CLOUD_NAME;
      const apiKey = process.env.CLOUDINARY_API_KEY;
      const apiSecret = process.env.CLOUDINARY_API_SECRET;
      if (!cloud || !apiKey || !apiSecret) {
        return NextResponse.json({ error: "Cloudinary credentials are required to delete this product's images" }, { status: 503 });
      }
      for (const publicId of publicIds) {
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const signature = createHash("sha1").update(`public_id=${publicId}&timestamp=${timestamp}${apiSecret}`).digest("hex");
        const payload = new FormData();
        payload.append("public_id", publicId);
        payload.append("api_key", apiKey);
        payload.append("timestamp", timestamp);
        payload.append("signature", signature);
        const response = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/image/destroy`, { method: "POST", body: payload });
        const result = await response.json() as { result?: string; error?: { message?: string } };
        if (!response.ok || (result.result !== "ok" && result.result !== "not found")) {
          console.error("Cloudinary image deletion failed", { status: response.status, providerMessage: result.error?.message });
          return NextResponse.json({ error: "Image provider could not delete this product's images" }, { status: 502 });
        }
      }
    }
    await db.$transaction(async (tx) => {
      await tx.cartItem.deleteMany({ where: { productId: id } });
      await tx.wishlistItem.deleteMany({ where: { productId: id } });
      await tx.review.deleteMany({ where: { productId: id } });
      await tx.product.delete({ where: { id } });
    });
    return NextResponse.json({ ok: true, archived: false });
  } catch (error) { return errorResponse(error); }
}
