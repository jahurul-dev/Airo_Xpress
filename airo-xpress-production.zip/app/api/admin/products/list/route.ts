import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const [products, categories] = await Promise.all([
      db.product.findMany({
        orderBy: { createdAt: "desc" }, take: 200,
        include: { category: { select: { name: true } }, images: { orderBy: { position: "asc" } } }
      }),
      db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } })
    ]);
    return NextResponse.json({ products, categories });
  } catch (error) { return errorResponse(error); }
}
