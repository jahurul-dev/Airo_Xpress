import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const customers = await db.user.findMany({
      where: { role: UserRole.CUSTOMER },
      orderBy: { createdAt: "desc" },
      take: 500,
      select: {
        id: true, name: true, email: true, phone: true, createdAt: true,
        _count: { select: { orders: true } }
      }
    });
    return NextResponse.json({ customers });
  } catch (error) { return errorResponse(error); }
}
