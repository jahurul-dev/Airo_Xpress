import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { ApiError, errorResponse, requireSameOrigin, slugify } from "@/lib/http";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const body = z.object({ name: z.string().trim().min(2).max(80) }).parse(await request.json());
    const category = await db.category.update({ where: { id }, data: { name: body.name, slug: slugify(body.name) } });
    return NextResponse.json({ category });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const category = await db.category.findUnique({ where: { id }, select: { id: true, _count: { select: { products: true } } } });
    if (!category) throw new ApiError("Category not found", 404);
    if (category._count.products > 0) throw new ApiError("Move or remove this category's products before deleting it.", 409);
    await db.category.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
