import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin, slugify } from "@/lib/http";

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = z.object({ name: z.string().trim().min(2).max(80) }).parse(await request.json());
    const category = await db.category.create({
      data: { name: body.name, slug: `${slugify(body.name)}-${randomUUID().slice(0, 6)}` }
    });
    return NextResponse.json({ category }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
