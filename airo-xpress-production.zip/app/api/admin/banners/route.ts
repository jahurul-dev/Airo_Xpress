import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

const bannerSchema = z.object({
  title: z.string().trim().min(2).max(120),
  description: z.string().trim().max(500).optional(),
  imageUrl: z.string().url().startsWith("https://").optional(),
  linkUrl: z.string().trim().max(500).refine((value) =>
    (value.startsWith("/") && !value.startsWith("//")) || value.startsWith("https://")
  ).optional(),
  position: z.number().int().min(0).max(1000).default(0),
  isActive: z.boolean().default(true)
});

export async function GET() {
  try {
    await requireUser(UserRole.ADMIN);
    const banners = await db.banner.findMany({ orderBy: [{ position: "asc" }, { createdAt: "desc" }] });
    return NextResponse.json({ banners });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = bannerSchema.parse(await request.json());
    const banner = await db.banner.create({ data: body });
    return NextResponse.json({ banner }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
