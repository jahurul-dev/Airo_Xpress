import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { ApiError, errorResponse, requireSameOrigin } from "@/lib/http";

const bannerUpdateSchema = z.object({
  title: z.string().trim().min(2).max(120).optional(),
  description: z.string().trim().max(500).nullable().optional(),
  imageUrl: z.string().url().startsWith("https://").nullable().optional(),
  linkUrl: z.string().trim().max(500).refine((value) =>
    (value.startsWith("/") && !value.startsWith("//")) || value.startsWith("https://")
  ).nullable().optional(),
  position: z.number().int().min(0).max(1000).optional(),
  isActive: z.boolean().optional()
}).refine((value) => Object.keys(value).length > 0);

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const body = bannerUpdateSchema.parse(await request.json());
    const banner = await db.banner.update({ where: { id }, data: body });
    return NextResponse.json({ banner });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const { id } = await params;
    const banner = await db.banner.findUnique({ where: { id }, select: { id: true } });
    if (!banner) throw new ApiError("Banner not found", 404);
    await db.banner.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
