import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

export async function GET() {
  try {
    const user = await requireUser();
    const items = await db.wishlistItem.findMany({
      where: { userId: user.id },
      include: { product: { include: { images: { orderBy: { position: "asc" }, take: 1 }, category: { select: { name: true } } } } },
      orderBy: { createdAt: "desc" }
    });
    return NextResponse.json({ items });
  } catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = z.object({ productId: z.string().min(1) }).parse(await request.json());
    const item = await db.wishlistItem.upsert({
      where: { userId_productId: { userId: user.id, productId: body.productId } },
      create: { userId: user.id, productId: body.productId },
      update: {}
    });
    return NextResponse.json({ item }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}

export async function DELETE(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const productId = new URL(request.url).searchParams.get("productId");
    if (!productId) return NextResponse.json({ error: "productId is required" }, { status: 400 });
    await db.wishlistItem.deleteMany({ where: { userId: user.id, productId } });
    return NextResponse.json({ ok: true });
  } catch (error) { return errorResponse(error); }
}
