import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

const schema = z.object({ productId: z.string().min(1), rating: z.number().int().min(1).max(5), comment: z.string().trim().max(2000).optional() });

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const user = await requireUser();
    const body = schema.parse(await request.json());
    const purchase = await db.orderItem.findFirst({
      where: { productId: body.productId, order: { userId: user.id, status: "DELIVERED" } },
      select: { id: true }
    });
    if (!purchase) return NextResponse.json({ error: "Reviews are available after a verified delivery" }, { status: 403 });
    const review = await db.$transaction(async (tx) => {
      const saved = await tx.review.upsert({
        where: { userId_productId: { userId: user.id, productId: body.productId } },
        create: { userId: user.id, ...body },
        update: { rating: body.rating, comment: body.comment }
      });
      const aggregate = await tx.review.aggregate({ where: { productId: body.productId }, _avg: { rating: true }, _count: true });
      await tx.product.update({
        where: { id: body.productId },
        data: { rating: aggregate._avg.rating ?? 0, reviewCount: aggregate._count }
      });
      return saved;
    });
    return NextResponse.json({ review }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}
