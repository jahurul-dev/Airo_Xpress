import { NextResponse } from "next/server";
import { UserRole } from "@prisma/client";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";
import { deliveryTiers } from "@/lib/locations";

export async function GET() {
  const zones = await db.deliveryZone.findMany();
  return NextResponse.json({
    options: deliveryTiers.map((tier) => {
      const zone = zones.find((item) => item.cityPattern === tier.cityPattern);
      return {
        type: tier.code,
        name: tier.name,
        fee: Number(zone?.fee ?? tier.defaultFee),
        configured: Boolean(zone?.isActive)
      };
    }),
    zones
  });
}

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = z.object({
      type: z.enum(["INSIDE_DHAKA", "SUBURBAN_DHAKA", "OUTSIDE_DHAKA"]),
      fee: z.number().min(0).max(100000),
      isActive: z.boolean().default(true)
    }).parse(await request.json());
    const tier = deliveryTiers.find((option) => option.code === body.type);
    if (!tier) return NextResponse.json({ error: "Select a valid delivery tier." }, { status: 400 });
    const zone = await db.deliveryZone.upsert({
      where: { cityPattern: tier.cityPattern },
      create: { name: tier.name, cityPattern: tier.cityPattern, fee: body.fee, isActive: body.isActive },
      update: { name: tier.name, fee: body.fee, isActive: body.isActive }
    });
    return NextResponse.json({ zone }, { status: 201 });
  } catch (error) { return errorResponse(error); }
}

export async function PATCH(request: Request) {
  try {
    requireSameOrigin(request);
    await requireUser(UserRole.ADMIN);
    const body = z.object({
      id: z.string().min(1),
      fee: z.number().min(0).max(100000).optional(),
      isActive: z.boolean().optional()
    }).refine((value) => Object.keys(value).length > 1).parse(await request.json());
    const { id, ...data } = body;
    const current = await db.deliveryZone.findUnique({ where: { id }, select: { cityPattern: true } });
    if (!current || !deliveryTiers.some((tier) => tier.cityPattern === current.cityPattern)) {
      return NextResponse.json({ error: "Delivery tier not found" }, { status: 404 });
    }
    const zone = await db.deliveryZone.update({ where: { id }, data });
    return NextResponse.json({ zone });
  } catch (error) { return errorResponse(error); }
}
