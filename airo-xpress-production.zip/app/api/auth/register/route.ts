import { createHash, randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { clientRateLimitKey, enforceRateLimit, errorResponse, requireSameOrigin } from "@/lib/http";
import { sendTransactionalEmail } from "@/lib/email";
import { getAppUrl } from "@/lib/app-url";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(254).transform((value) => value.toLowerCase()),
  phone: z.string().trim().min(8).max(20).optional(),
  password: z.string().min(10).max(128)
});

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    if (!(await enforceRateLimit(clientRateLimitKey(request, "register"), 5, 60 * 60 * 1000))) {
      return NextResponse.json({ error: "Too many registration attempts. Try again later." }, { status: 429 });
    }
    const body = schema.parse(await request.json());
    const existing = await db.user.findFirst({
      where: { OR: [{ email: body.email }, ...(body.phone ? [{ phone: body.phone }] : [])] },
      select: { id: true }
    });
    if (existing) return NextResponse.json({ error: "An account with these details already exists" }, { status: 409 });
    const user = await db.user.create({
      data: {
        name: body.name,
        email: body.email,
        phone: body.phone,
        passwordHash: await bcrypt.hash(body.password, 12),
        cart: { create: {} }
      },
      select: { id: true, name: true, email: true }
    });
    const emailVerificationSent = Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM);
    if (emailVerificationSent) {
      const token = randomBytes(32).toString("base64url");
      await db.verificationToken.create({
        data: {
          tokenHash: createHash("sha256").update(token).digest("hex"),
          purpose: "EMAIL_VERIFY", userId: user.id,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
        }
      });
      const link = `${getAppUrl(request.url)}/verify-email?token=${encodeURIComponent(token)}`;
      await sendTransactionalEmail(user.email, "Verify your AIRO XPRESS email", `<p>Welcome to AIRO XPRESS.</p><p><a href="${link}">Verify your email address</a></p><p>This link expires in 24 hours.</p>`);
    }
    await createSession(user.id);
    return NextResponse.json({ user, emailVerificationSent }, { status: 201 });
  } catch (error) {
    return errorResponse(error);
  }
}
