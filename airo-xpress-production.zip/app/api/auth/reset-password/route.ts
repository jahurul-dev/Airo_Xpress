import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { errorResponse, requireSameOrigin } from "@/lib/http";

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    const body = z.object({ token: z.string().min(20).max(100), password: z.string().min(10).max(128) }).parse(await request.json());
    const tokenHash = createHash("sha256").update(body.token).digest("hex");
    const reset = await db.verificationToken.findFirst({
      where: { tokenHash, purpose: "PASSWORD_RESET", expiresAt: { gt: new Date() } }
    });
    if (!reset) return NextResponse.json({ error: "Reset link is invalid or expired. Request a new one." }, { status: 400 });
    const passwordHash = await bcrypt.hash(body.password, 12);
    await db.$transaction([
      db.user.update({ where: { id: reset.userId }, data: { passwordHash } }),
      db.session.deleteMany({ where: { userId: reset.userId } }),
      db.verificationToken.deleteMany({ where: { userId: reset.userId, purpose: "PASSWORD_RESET" } })
    ]);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
