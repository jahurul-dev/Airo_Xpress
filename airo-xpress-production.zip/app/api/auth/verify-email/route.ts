import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { errorResponse } from "@/lib/http";

export async function POST(request: Request) {
  try {
    const { token } = z.object({ token: z.string().min(20).max(100) }).parse(await request.json());
    const tokenHash = createHash("sha256").update(token).digest("hex");
    const verification = await db.verificationToken.findFirst({
      where: { tokenHash, purpose: "EMAIL_VERIFY", expiresAt: { gt: new Date() } }
    });
    if (!verification) return NextResponse.json({ error: "Verification link is invalid or expired." }, { status: 400 });
    await db.$transaction([
      db.user.update({ where: { id: verification.userId }, data: { emailVerified: new Date() } }),
      db.verificationToken.deleteMany({ where: { userId: verification.userId, purpose: "EMAIL_VERIFY" } })
    ]);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
