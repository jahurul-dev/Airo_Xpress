import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { clientRateLimitKey, enforceRateLimit, errorResponse, requireSameOrigin } from "@/lib/http";

const schema = z.object({
  email: z.string().trim().email().transform((value) => value.toLowerCase()),
  password: z.string().min(1).max(128)
});

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    if (!(await enforceRateLimit(clientRateLimitKey(request, "login"), 8, 15 * 60 * 1000))) {
      return NextResponse.json({ error: "Too many sign-in attempts. Try again in 15 minutes." }, { status: 429 });
    }
    const body = schema.parse(await request.json());
    const user = await db.user.findUnique({ where: { email: body.email } });
    if (!user || !(await bcrypt.compare(body.password, user.passwordHash))) {
      return NextResponse.json({ error: "Email or password is incorrect" }, { status: 401 });
    }
    await createSession(user.id);
    return NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    return errorResponse(error);
  }
}
