import { createHash, randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sendTransactionalEmail } from "@/lib/email";
import { clientRateLimitKey, enforceRateLimit, errorResponse, requireSameOrigin } from "@/lib/http";
import { getAppUrl } from "@/lib/app-url";

export async function POST(request: Request) {
  try {
    requireSameOrigin(request);
    if (!(await enforceRateLimit(clientRateLimitKey(request, "password-reset"), 5, 60 * 60 * 1000))) {
      return NextResponse.json({ error: "Too many requests. Try again later." }, { status: 429 });
    }
    const appUrl = getAppUrl(request.url);
    const { email } = z.object({ email: z.string().email().transform((value) => value.toLowerCase()) }).parse(await request.json());
    const token = randomBytes(32).toString("base64url");
    const user = await db.user.findUnique({ where: { email }, select: { id: true } });
    if (user) {
      await db.verificationToken.deleteMany({ where: { userId: user.id, purpose: "PASSWORD_RESET" } });
      await db.verificationToken.create({
        data: {
          tokenHash: createHash("sha256").update(token).digest("hex"),
          purpose: "PASSWORD_RESET", userId: user.id,
          expiresAt: new Date(Date.now() + 60 * 60 * 1000)
        }
      });
    }
    const link = `${appUrl}/reset-password?token=${encodeURIComponent(token)}`;
    await sendTransactionalEmail(
      email,
      "Reset your AIRO XPRESS password",
      `<p>If an AIRO XPRESS account exists for this address, use this link to reset the password:</p><p><a href="${link}">Reset password</a></p><p>This link expires in one hour. Ignore this email if you did not request a reset.</p>`
    );
    return NextResponse.json({ message: "If an account exists for that email, password reset instructions have been sent." });
  } catch (error) {
    return errorResponse(error);
  }
}
