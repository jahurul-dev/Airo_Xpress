"use client";

import Image from "next/image";
import Link from "next/link";
import { ChangeEvent, FormEvent, useEffect, useState } from "react";

type Category = { id: string; name: string };
type Banner = { id: string; title: string; description: string | null; imageUrl: string | null; linkUrl: string | null; position: number; isActive: boolean };
type ProductImage = { id?: string; url: string; publicId?: string | null; alt?: string };
type Product = {
  id: string; slug: string; name: string; description: string; price: string | number; compareAtPrice: string | number | null;
  stock: number; isActive: boolean; brand: string | null; categoryId: string; category: Category; images: ProductImage[];
};
type Vendor = { id: string; storeName: string; status: string; user: { name: string; email: string } };
type Order = {
  id: string; orderNumber: string; status: string; total: string | number; createdAt: string;
  customer: { name: string; email: string; phone: string | null }; items: { productName: string; quantity: number }[];
};
type Zone = { id: string; name: string; cityPattern: string; fee: string | number; isActive: boolean };
type Coupon = { id: string; code: string; percentOff: number | null; amountOff: string | number | null; isActive: boolean; uses: number; maxUses: number | null };
type Customer = { id: string; name: string; email: string; phone: string | null; createdAt: string; _count: { orders: number } };
type Dashboard = {
  metrics: Record<string, number>;
  dailySales: { period: string; revenue: number; orders: number }[];
  monthlySales: { period: string; revenue: number; orders: number }[];
  topProducts: { name: string; quantity: number }[];
};
type MarketingSales = {
  productId: string; productName: string; orderCount: number; unitCount: number;
  deliveredOrderCount: number; deliveredUnitCount: number; deliveredRevenue: number;
};
type MarketingTracking = {
  pixelConfigured: boolean; conversionsApiConfigured: boolean;
  graphApiVersionConfigured: boolean; testEventCodeConfigured: boolean;
};
type OrderDetails = Omit<Order, "items"> & {
  deliveryAddress: Record<string, unknown>; deliveryTier: string; deliveryFee: string | number;
  subtotal: string | number; discount: string | number; couponCode: string | null;
  items: { productName: string; quantity: number; unitPrice: string | number; productImage: string | null }[];
  payment: { method: string; status: string; amount: string | number } | null;
  shipment: { trackingNumber: string | null; carrier: string | null; deliveredAt: string | null } | null;
};

const tiers = [
  { type: "INSIDE_DHAKA", label: "Inside Dhaka" },
  { type: "SUBURBAN_DHAKA", label: "Suburban Dhaka" },
  { type: "OUTSIDE_DHAKA", label: "Outside Dhaka" }
] as const;
const orderStatuses = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED", "RETURN_REQUESTED", "REFUNDED"];
const money = (value: string | number) => `৳${Number(value).toLocaleString("en-BD")}`;

async function responseData(response: Response) {
  const data = await response.json();
  if (!response.ok) throw new Error(data.error ?? "The request could not be completed.");
  return data;
}

export default function AdminPage() {
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [marketingSales, setMarketingSales] = useState<MarketingSales[]>([]);
  const [marketingTracking, setMarketingTracking] = useState<MarketingTracking | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [createImages, setCreateImages] = useState<ProductImage[]>([]);
  const [editing, setEditing] = useState<Product | null>(null);
  const [editImages, setEditImages] = useState<ProductImage[]>([]);
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [bannerImage, setBannerImage] = useState("");

  async function load() {
    const responses = await Promise.all([
      fetch("/api/admin/dashboard"), fetch("/api/admin/products/list"), fetch("/api/admin/orders"),
      fetch("/api/admin/vendors"), fetch("/api/delivery-zones"), fetch("/api/admin/coupons"),
      fetch("/api/admin/customers"), fetch("/api/admin/banners"), fetch("/api/admin/marketing")
    ]);
    if (responses.some((response) => response.status === 401 || response.status === 403)) {
      window.location.href = "/login?next=/admin";
      throw new Error("Administrator access is required.");
    }
    const [stats, productData, orderData, vendorData, zoneData, couponData, customerData, bannerData, marketingData] =
      await Promise.all(responses.map(responseData));
    setDashboard(stats);
    setProducts(productData.products);
    setCategories(productData.categories);
    setOrders(orderData.orders);
    setVendors(vendorData.vendors);
    setZones(zoneData.zones);
    setCoupons(couponData.coupons);
    setCustomers(customerData.customers);
    setBanners(bannerData.banners);
    setMarketingSales(marketingData.productSales);
    setMarketingTracking(marketingData.tracking);
  }

  useEffect(() => { load().catch((reason: Error) => setError(reason.message)); }, []);

  async function uploadFiles(files: FileList | null, currentCount: number, setImages: (images: ProductImage[]) => void, currentImages: ProductImage[]) {
    if (!files?.length) return;
    if (currentCount + files.length > 8) { setError("A product can have up to eight images."); return; }
    setBusy(true); setError("");
    try {
      const uploaded = await Promise.all(Array.from(files).map(async (file) => {
        const form = new FormData();
        form.append("file", file);
        const result = await responseData(await fetch("/api/upload", { method: "POST", body: form }));
        return { url: result.url as string, publicId: result.publicId as string, alt: file.name };
      }));
      setImages([...currentImages, ...uploaded]);
      setNotice(`${uploaded.length} image${uploaded.length === 1 ? "" : "s"} uploaded.`);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Image upload failed.");
    } finally { setBusy(false); }
  }

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    setBusy(true); setError("");
    try {
      await responseData(await fetch("/api/admin/products", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.get("name"), description: form.get("description"), categoryId: form.get("categoryId"),
          price: Number(form.get("price")), compareAtPrice: form.get("compareAtPrice") ? Number(form.get("compareAtPrice")) : undefined,
          stock: Number(form.get("stock")), brand: form.get("brand") || undefined, images: createImages
        })
      }));
      setCreateImages([]); formElement.reset(); setNotice("Product added to the catalogue."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not create product."); }
    finally { setBusy(false); }
  }

  function beginEdit(product: Product) {
    setEditing(product);
    setEditImages(product.images.map((image) => ({ ...image })));
    setError(""); setNotice("");
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editing) return;
    const form = new FormData(event.currentTarget);
    setBusy(true); setError("");
    try {
      await responseData(await fetch(`/api/admin/products/${editing.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.get("name"), description: form.get("description"), categoryId: form.get("categoryId"),
          price: Number(form.get("price")), compareAtPrice: form.get("compareAtPrice") ? Number(form.get("compareAtPrice")) : null,
          stock: Number(form.get("stock")), brand: form.get("brand") || null,
          isActive: form.get("isActive") === "on", images: editImages
        })
      }));
      setNotice("Product changes saved."); setEditing(null); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not update product."); }
    finally { setBusy(false); }
  }

  async function removeImage(image: ProductImage, index: number, mode: "create" | "edit") {
    if (image.id) {
      try {
        await responseData(await fetch("/api/upload", {
          method: "DELETE", headers: { "Content-Type": "application/json" },
          body: JSON.stringify(image.id ? { imageId: image.id } : { publicId: image.publicId })
        }));
      } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not remove image."); return; }
    }
    if (mode === "create") setCreateImages((images) => images.filter((_, position) => position !== index));
    else setEditImages((images) => images.filter((_, position) => position !== index));
    setNotice("Image removed.");
  }

  async function patch(endpoint: string, body: object) {
    setError(""); setBusy(true);
    try {
      await responseData(await fetch(endpoint, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }));
      setNotice("Changes saved."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Update failed."); }
    finally { setBusy(false); }
  }

  async function createCoupon(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const discountType = String(form.get("discountType"));
    const value = Number(form.get("discountValue"));
    setBusy(true); setError("");
    try {
      await responseData(await fetch("/api/admin/coupons", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: form.get("code"), minSubtotal: Number(form.get("minSubtotal") || 0),
          ...(discountType === "percent" ? { percentOff: value } : { amountOff: value }),
          maxUses: form.get("maxUses") ? Number(form.get("maxUses")) : undefined
        })
      }));
      formElement.reset(); setNotice("Coupon created."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not create coupon."); }
    finally { setBusy(false); }
  }

  async function createCategory(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    setBusy(true); setError("");
    try {
      await responseData(await fetch("/api/admin/categories", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: form.get("name") })
      }));
      formElement.reset(); setNotice("Category created."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not create category."); }
    finally { setBusy(false); }
  }

  async function uploadBannerImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setBusy(true); setError("");
    try {
      const form = new FormData();
      form.append("file", file);
      const result = await responseData(await fetch("/api/upload", { method: "POST", body: form }));
      setBannerImage(result.url);
      setNotice("Banner image uploaded.");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Banner image upload failed."); }
    finally { setBusy(false); }
  }

  async function createBanner(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    setBusy(true); setError("");
    try {
      await responseData(await fetch("/api/admin/banners", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: form.get("title"), description: form.get("description") || undefined,
          imageUrl: bannerImage || undefined, linkUrl: form.get("linkUrl") || undefined,
          position: Number(form.get("position") || 0)
        })
      }));
      formElement.reset(); setBannerImage(""); setNotice("Homepage promotion created."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not create promotion."); }
    finally { setBusy(false); }
  }

  async function removeBanner(banner: Banner) {
    if (!window.confirm(`Delete homepage promotion "${banner.title}"?`)) return;
    setBusy(true); setError("");
    try {
      await responseData(await fetch(`/api/admin/banners/${banner.id}`, { method: "DELETE" }));
      setNotice("Homepage promotion deleted."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not delete promotion."); }
    finally { setBusy(false); }
  }

  async function renameCategory(category: Category) {
    const name = window.prompt("Enter the new category name:", category.name)?.trim();
    if (!name || name === category.name) return;
    await patch(`/api/admin/categories/${category.id}`, { name });
  }

  async function removeCategory(category: Category) {
    if (!window.confirm(`Delete category "${category.name}"?`)) return;
    setBusy(true); setError("");
    try {
      await responseData(await fetch(`/api/admin/categories/${category.id}`, { method: "DELETE" }));
      setNotice("Category deleted."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not delete category."); }
    finally { setBusy(false); }
  }

  async function saveZone(event: FormEvent<HTMLFormElement>, type: typeof tiers[number]["type"]) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const current = zones.find((zone) => zone.cityPattern === type.toLowerCase());
    const method = current ? "PATCH" : "POST";
    const body = current
      ? { id: current.id, fee: Number(form.get("fee")), isActive: form.get("isActive") === "on" }
      : { type, fee: Number(form.get("fee")), isActive: form.get("isActive") === "on" };
    setBusy(true); setError("");
    try {
      await responseData(await fetch("/api/delivery-zones", { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }));
      setNotice("Delivery fee saved."); await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not save delivery fee."); }
    finally { setBusy(false); }
  }

  async function showOrder(orderId: string) {
    try {
      const data = await responseData(await fetch(`/api/admin/orders/${orderId}`));
      setOrderDetails(data.order);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not load order."); }
  }

  async function copyMarketingValue(value: string, label: string) {
    try {
      await navigator.clipboard.writeText(value);
      setError("");
      setNotice(`${label} copied.`);
    } catch {
      setError("Clipboard access is unavailable in this browser.");
    }
  }

  function getProductUrl(product: Product) {
    return new URL(`/product/${encodeURIComponent(product.slug)}`, window.location.origin).toString();
  }

  async function removeProduct(product: Product) {
    if (!window.confirm(`Remove "${product.name}" from the catalogue?`)) return;
    setBusy(true); setError("");
    try {
      const result = await responseData(await fetch(`/api/admin/products/${product.id}`, { method: "DELETE" }));
      setNotice(result.archived
        ? "Product archived to preserve its order history."
        : "Product and its unused images were permanently deleted.");
      await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not remove product."); }
    finally { setBusy(false); }
  }

  async function uploadFor(event: ChangeEvent<HTMLInputElement>, images: ProductImage[], setImages: (value: ProductImage[]) => void) {
    await uploadFiles(event.target.files, images.length, setImages, images);
    event.target.value = "";
  }

  return <div className="container content-page">
    <div className="page-title"><span className="eyebrow">AIRO XPRESS CONTROL ROOM</span><h1>Admin dashboard</h1></div>
    <div className="account-layout">
      <nav className="account-nav"><a href="#overview">Overview</a><a href="#products">Products</a><a href="#marketing">Marketing &amp; advertising</a><a href="#categories">Categories</a><a href="#banners">Banners</a><a href="#orders">Orders</a><a href="#customers">Customers</a><a href="#vendors">Vendors</a><a href="#coupons">Coupons</a><Link href="/shop">View storefront ↗</Link></nav>
      <div>
        {error && <div className="notice notice-error" role="alert">{error}</div>}
        {notice && <div className="notice notice-success" role="status">{notice}</div>}
        <section id="overview" className="admin-grid">{dashboard ? <>
          <Metric label="Delivered revenue" value={money(dashboard.metrics.revenue)} />
          <Metric label="All orders" value={dashboard.metrics.orders} /><Metric label="Customers" value={dashboard.metrics.customers} />
          <Metric label="Products" value={dashboard.metrics.products} /><Metric label="Pending orders" value={dashboard.metrics.pendingOrders} /><Metric label="Delivered orders" value={dashboard.metrics.completedOrders} />
        </> : <p className="muted-copy">Loading dashboard…</p>}</section>

        {dashboard && <section className="admin-grid" style={{ marginTop: 16 }}>
          <div className="account-panel"><h2>Daily sales · last 30 days</h2>{dashboard.dailySales.length ? dashboard.dailySales.map((row) => <p key={row.period}>{new Date(row.period).toLocaleDateString()} · {money(row.revenue)} · {row.orders} orders</p>) : <p className="muted-copy">No delivered orders in this period.</p>}</div>
          <div className="account-panel"><h2>Monthly sales · last 12 months</h2>{dashboard.monthlySales.length ? dashboard.monthlySales.map((row) => <p key={row.period}>{new Date(row.period).toLocaleDateString(undefined, { month: "short", year: "numeric" })} · {money(row.revenue)} · {row.orders} orders</p>) : <p className="muted-copy">No delivered orders in this period.</p>}</div>
          <div className="account-panel"><h2>Best sellers</h2>{dashboard.topProducts.length ? dashboard.topProducts.map((item) => <p key={item.name}>{item.name} · {item.quantity} sold</p>) : <p className="muted-copy">No delivered product sales yet.</p>}</div>
        </section>}

        <section id="categories" className="account-panel" style={{ marginBottom: 18 }}><h2>Product categories</h2>
          <form onSubmit={createCategory} className="admin-grid"><div className="form-field"><label htmlFor="category-name">New category name</label><input id="category-name" name="name" required minLength={2} maxLength={80} /></div><button className="button button-outline" disabled={busy}>Add category</button></form>
          <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Category</th><th>Actions</th></tr></thead><tbody>{categories.map((category) => <tr key={category.id}><td>{category.name}</td><td><button className="remove-button" disabled={busy} onClick={() => renameCategory(category)}>Rename</button> <button className="remove-button" disabled={busy} onClick={() => removeCategory(category)}>Delete</button></td></tr>)}</tbody></table></div>
        </section>

        <section id="banners" className="account-panel" style={{ marginBottom: 18 }}><h2>Homepage promotions</h2>
          <form onSubmit={createBanner}>
            <div className="admin-grid">
              <div className="form-field"><label htmlFor="banner-title">Title</label><input id="banner-title" name="title" required minLength={2} maxLength={120} /></div>
              <div className="form-field"><label htmlFor="banner-description">Description</label><input id="banner-description" name="description" maxLength={500} /></div>
              <div className="form-field"><label htmlFor="banner-link">Link (optional, local path or HTTPS URL)</label><input id="banner-link" name="linkUrl" type="url" /></div>
              <div className="form-field"><label htmlFor="banner-position">Display order</label><input id="banner-position" name="position" type="number" min="0" max="1000" defaultValue="0" /></div>
            </div>
            <div className="form-field"><label htmlFor="banner-image">Banner image (optional, JPEG/PNG/WebP, max 5 MB)</label><input id="banner-image" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={uploadBannerImage} /></div>
            {bannerImage && <Image src={bannerImage} alt="Uploaded banner preview" width={240} height={100} unoptimized />}
            <button className="button button-outline" disabled={busy}>Add homepage promotion</button>
          </form>
          <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Title</th><th>Order</th><th>Status</th><th>Action</th></tr></thead><tbody>{banners.map((banner) => <tr key={banner.id}><td>{banner.title}</td><td>{banner.position}</td><td>{banner.isActive ? "Visible" : "Hidden"}</td><td><button className="remove-button" disabled={busy} onClick={() => patch(`/api/admin/banners/${banner.id}`, { isActive: !banner.isActive })}>{banner.isActive ? "Hide" : "Show"}</button> <button className="remove-button" disabled={busy} onClick={() => removeBanner(banner)}>Delete</button></td></tr>)}</tbody></table></div>
        </section>

        <section id="products" className="account-panel" style={{ marginTop: 18, marginBottom: 18 }}>
          <h2>Add a product</h2>
          <form onSubmit={createProduct}>
            <div className="form-field"><label htmlFor="p-name">Product name</label><input id="p-name" name="name" required minLength={2} maxLength={180} /></div>
            <div className="form-field"><label htmlFor="p-description">Description</label><textarea id="p-description" name="description" required minLength={10} /></div>
            <div className="form-field"><label htmlFor="p-category">Category</label><select id="p-category" name="categoryId" required defaultValue=""><option value="" disabled>Select category</option>{categories.map((category) => <option value={category.id} key={category.id}>{category.name}</option>)}</select></div>
            <div className="admin-grid">
              <div className="form-field"><label htmlFor="p-price">Price (BDT)</label><input id="p-price" name="price" type="number" min="0.01" step="0.01" required /></div>
              <div className="form-field"><label htmlFor="p-compare">Compare-at price</label><input id="p-compare" name="compareAtPrice" type="number" min="0.01" step="0.01" /></div>
              <div className="form-field"><label htmlFor="p-stock">Stock</label><input id="p-stock" name="stock" type="number" min="0" required /></div>
            </div>
            <div className="form-field"><label htmlFor="p-brand">Brand (optional)</label><input id="p-brand" name="brand" maxLength={100} /></div>
            <div className="form-field"><label htmlFor="p-image">Product images (JPEG, PNG or WebP, max 5 MB each, up to 8)</label><input id="p-image" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy} onChange={(event) => uploadFor(event, createImages, setCreateImages)} /></div>
            <ImageList images={createImages} onRemove={(image, index) => removeImage(image, index, "create")} />
            <button className="button button-primary" disabled={busy}>Create product <span>→</span></button>
          </form>
        </section>

        {editing && <section className="account-panel" style={{ marginBottom: 18 }}><h2>Edit product</h2>
          <form onSubmit={saveProduct}>
            <div className="form-field"><label htmlFor="e-name">Product name</label><input id="e-name" name="name" required minLength={2} defaultValue={editing.name} /></div>
            <div className="form-field"><label htmlFor="e-description">Description</label><textarea id="e-description" name="description" required minLength={10} defaultValue={editing.description} /></div>
            <div className="form-field"><label htmlFor="e-category">Category</label><select id="e-category" name="categoryId" defaultValue={editing.categoryId}>{categories.map((category) => <option value={category.id} key={category.id}>{category.name}</option>)}</select></div>
            <div className="admin-grid">
              <div className="form-field"><label htmlFor="e-price">Price (BDT)</label><input id="e-price" name="price" type="number" min="0.01" step="0.01" required defaultValue={Number(editing.price)} /></div>
              <div className="form-field"><label htmlFor="e-compare">Compare-at price</label><input id="e-compare" name="compareAtPrice" type="number" min="0.01" step="0.01" defaultValue={editing.compareAtPrice ? Number(editing.compareAtPrice) : ""} /></div>
              <div className="form-field"><label htmlFor="e-stock">Stock</label><input id="e-stock" name="stock" type="number" min="0" required defaultValue={editing.stock} /></div>
            </div>
            <div className="form-field"><label htmlFor="e-brand">Brand</label><input id="e-brand" name="brand" defaultValue={editing.brand ?? ""} /></div>
            <label><input type="checkbox" name="isActive" defaultChecked={editing.isActive} /> Visible in catalogue</label>
            <div className="form-field"><label htmlFor="e-image">Add product images</label><input id="e-image" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy} onChange={(event) => uploadFor(event, editImages, setEditImages)} /></div>
            <ImageList images={editImages} onRemove={(image, index) => removeImage(image, index, "edit")} />
            <button className="button button-primary" disabled={busy}>Save product</button> <button type="button" className="button button-outline" onClick={() => setEditing(null)}>Cancel</button>
          </form>
        </section>}

        <section className="account-panel" style={{ marginBottom: 18 }}><h2>Catalogue ({products.length})</h2><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Visibility</th><th>Actions</th></tr></thead><tbody>{products.map((product) => <tr key={product.id}><td>{product.name}</td><td>{product.category.name}</td><td>{money(product.price)}</td><td>{product.stock}</td><td>{product.isActive ? "Active" : "Hidden"}</td><td><button className="remove-button" onClick={() => beginEdit(product)}>Edit</button> <button className="remove-button" disabled={busy} onClick={() => patch(`/api/admin/products/${product.id}`, { isActive: !product.isActive })}>{product.isActive ? "Hide" : "Restore"}</button> <button className="remove-button" disabled={busy} onClick={() => removeProduct(product)}>Delete</button></td></tr>)}</tbody></table></div></section>

        <section id="marketing" className="account-panel" style={{ marginBottom: 18 }}>
          <h2>Marketing &amp; advertising</h2>
          <p className="muted-copy">Share product landing pages and review delivered product sales. Campaign creation and budgets remain in Meta Ads Manager.</p>
          <div className="admin-grid">
            <div><b>Meta Pixel</b><p>{marketingTracking?.pixelConfigured ? "Pixel ID configured" : "Not configured"}</p></div>
            <div><b>Conversions API</b><p>{marketingTracking?.conversionsApiConfigured ? "Server-side Purchase tracking configured" : "Not configured"}{marketingTracking?.graphApiVersionConfigured ? " · Graph API version set" : ""}</p></div>
            <div><b>Event testing</b><p>{marketingTracking?.testEventCodeConfigured ? "Test event code configured; verify receipt in Events Manager" : "Not tested; add a test event code to verify server events"}</p></div>
          </div>
          <p className="muted-copy">Purchase events fire after the server saves an order. For cash-on-delivery, this means an order was placed, not that payment was collected.</p>
          <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Product</th><th>Product-wise orders</th><th>Units</th><th>Delivered sales</th><th>Advertising tools</th></tr></thead><tbody>
            {products.map((product) => {
              const sales = marketingSales.find((item) => item.productId === product.id);
              return <tr key={product.id}>
                <td>{product.name}<br /><small>{product.isActive ? "Active product" : "Hidden product"}</small></td>
                <td>{sales?.orderCount ?? 0}<br /><small>{sales?.deliveredOrderCount ?? 0} delivered</small></td>
                <td>{sales?.unitCount ?? 0}<br /><small>{sales?.deliveredUnitCount ?? 0} delivered</small></td>
                <td>{money(sales?.deliveredRevenue ?? 0)}</td>
                <td><div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  <button type="button" className="remove-button" disabled={!product.isActive} onClick={() => copyMarketingValue(getProductUrl(product), "Product link")}>Copy link</button>
                  <button type="button" className="remove-button" onClick={() => copyMarketingValue(product.name, "Product name")}>Copy name</button>
                  <button type="button" className="remove-button" onClick={() => copyMarketingValue(money(product.price), "Product price")}>Copy price</button>
                  <button type="button" className="remove-button" onClick={() => copyMarketingValue(product.description, "Product description")}>Copy description</button>
                </div></td>
              </tr>;
            })}
            {!products.length && <tr><td colSpan={5}>Add products to the catalogue to create advertising links.</td></tr>}
          </tbody></table></div>
        </section>

        <section id="orders" className="account-panel" style={{ marginBottom: 18 }}><div className="page-title"><h2>Orders</h2><Link className="button button-outline" href="/api/admin/orders/export">Export CSV</Link></div><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Manage</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id}><td>{order.orderNumber}<br /><button className="remove-button" onClick={() => showOrder(order.id)}>Details</button></td><td>{order.customer.name}<br /><small>{order.customer.email || order.customer.phone || "No contact email"}</small></td><td>{order.items.length}</td><td>{money(order.total)}</td><td><span className="status-pill">{order.status}</span></td><td><select aria-label={`Update ${order.orderNumber}`} value={order.status} disabled={busy} onChange={(event) => patch(`/api/admin/orders/${order.id}`, { status: event.target.value })}>{orderStatuses.map((status) => <option key={status}>{status}</option>)}</select></td></tr>)}</tbody></table></div></section>

        <section id="customers" className="account-panel" style={{ marginBottom: 18 }}><h2>Customers ({customers.length})</h2><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Joined</th></tr></thead><tbody>{customers.map((customer) => <tr key={customer.id}><td>{customer.name}</td><td>{customer.email}</td><td>{customer.phone ?? "—"}</td><td>{customer._count.orders}</td><td>{new Date(customer.createdAt).toLocaleDateString()}</td></tr>)}</tbody></table></div></section>

        <section id="coupons" className="account-panel" style={{ marginBottom: 18 }}><h2>Coupons</h2>
          <form onSubmit={createCoupon} className="admin-grid">
            <div className="form-field"><label htmlFor="coupon-code">Code</label><input id="coupon-code" name="code" required minLength={3} maxLength={40} /></div>
            <div className="form-field"><label htmlFor="coupon-type">Discount type</label><select id="coupon-type" name="discountType"><option value="percent">Percent</option><option value="amount">Fixed amount (BDT)</option></select></div>
            <div className="form-field"><label htmlFor="coupon-value">Discount value</label><input id="coupon-value" name="discountValue" type="number" min="0.01" step="0.01" required /></div>
            <div className="form-field"><label htmlFor="coupon-minimum">Minimum subtotal</label><input id="coupon-minimum" name="minSubtotal" type="number" min="0" step="0.01" defaultValue="0" /></div>
            <div className="form-field"><label htmlFor="coupon-uses">Maximum uses (optional)</label><input id="coupon-uses" name="maxUses" type="number" min="1" /></div>
            <button className="button button-primary" disabled={busy}>Create coupon</button>
          </form>
          <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Code</th><th>Discount</th><th>Uses</th><th>Status</th><th>Action</th></tr></thead><tbody>{coupons.map((coupon) => <tr key={coupon.id}><td>{coupon.code}</td><td>{coupon.percentOff ? `${coupon.percentOff}%` : money(coupon.amountOff ?? 0)}</td><td>{coupon.uses}{coupon.maxUses ? ` / ${coupon.maxUses}` : ""}</td><td>{coupon.isActive ? "Active" : "Disabled"}</td><td><button className="remove-button" onClick={() => patch(`/api/admin/coupons/${coupon.id}`, { isActive: !coupon.isActive })}>{coupon.isActive ? "Disable" : "Enable"}</button></td></tr>)}</tbody></table></div>
        </section>

        <section id="vendors" className="account-panel" style={{ marginBottom: 18 }}><h2>Seller applications</h2><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Store</th><th>Owner</th><th>Email</th><th>Status</th><th>Review</th></tr></thead><tbody>{vendors.map((vendor) => <tr key={vendor.id}><td>{vendor.storeName}</td><td>{vendor.user.name}</td><td>{vendor.user.email}</td><td>{vendor.status}</td><td><select aria-label={`Update ${vendor.storeName}`} disabled={busy} value={vendor.status} onChange={(event) => patch(`/api/admin/vendors/${vendor.id}`, { status: event.target.value })}>{["PENDING", "APPROVED", "SUSPENDED"].map((status) => <option key={status}>{status}</option>)}</select></td></tr>)}</tbody></table></div></section>

        <section className="account-panel"><h2>Delivery fees</h2><p className="muted-copy">Configure the server-verified checkout price for each Bangladesh delivery tier.</p>
          {tiers.map((tier) => {
            const zone = zones.find((item) => item.cityPattern === tier.type.toLowerCase());
            return <form key={tier.type} onSubmit={(event) => saveZone(event, tier.type)} className="admin-grid" style={{ alignItems: "end", borderTop: "1px solid var(--border)", paddingTop: 12 }}>
              <div className="form-field"><label htmlFor={`fee-${tier.type}`}>{tier.label} fee (BDT)</label><input id={`fee-${tier.type}`} name="fee" type="number" min="0" step="0.01" required defaultValue={zone ? Number(zone.fee) : 0} /></div>
              <label><input type="checkbox" name="isActive" defaultChecked={zone?.isActive ?? false} /> Available at checkout</label>
              <button className="button button-outline" disabled={busy}>{zone ? "Save fee" : "Configure tier"}</button>
            </form>;
          })}
        </section>
      </div>
    </div>
    {orderDetails && <div className="modal-backdrop" role="presentation" onClick={() => setOrderDetails(null)}>
      <section className="account-panel order-detail-modal" role="dialog" aria-modal="true" aria-labelledby="order-modal-title" onClick={(event) => event.stopPropagation()}>
        <button className="remove-button" style={{ float: "right" }} onClick={() => setOrderDetails(null)}>Close</button>
        <h2 id="order-modal-title">Order {orderDetails.orderNumber}</h2><p>{orderDetails.status} · {new Date(orderDetails.createdAt).toLocaleString()}</p>
        <h3>Customer</h3><p>{orderDetails.customer.name} · {orderDetails.customer.email || "No email"} · {orderDetails.customer.phone ?? "No phone"}</p>
        <h3>Delivery address</h3><p>{Object.values(orderDetails.deliveryAddress).filter((value) => typeof value === "string" && value).join(", ")}</p>
        <h3>Items</h3>{orderDetails.items.map((item, index) => <div key={`${item.productName}-${index}`} className="order-detail-item">{item.productImage && <Image src={item.productImage} alt="" width={50} height={50} unoptimized />}<p>{item.productName} × {item.quantity} · {money(Number(item.unitPrice) * item.quantity)}</p></div>)}
        <p>Subtotal {money(orderDetails.subtotal)} · Delivery {money(orderDetails.deliveryFee)} · Discount {money(orderDetails.discount)}{orderDetails.couponCode ? ` (${orderDetails.couponCode})` : ""}</p>
        <strong>Total {money(orderDetails.total)}</strong>
        <h3>Payment and delivery</h3><p>{orderDetails.payment ? `${orderDetails.payment.method} · ${orderDetails.payment.status}` : "No payment record"} · {orderDetails.shipment?.trackingNumber ?? "No tracking number"}</p>
      </section>
    </div>}
  </div>;
}

function ImageList({ images, onRemove }: { images: ProductImage[]; onRemove: (image: ProductImage, index: number) => void }) {
  if (!images.length) return <p className="muted-copy">No product images selected.</p>;
  return <div className="admin-image-list">{images.map((image, index) => <div key={image.id ?? `${image.publicId}-${index}`}>
    <Image src={image.url} alt={image.alt ?? "Product image"} width={90} height={90} unoptimized />
    <button type="button" className="remove-button" onClick={() => onRemove(image, index)}>Remove</button>
  </div>)}</div>;
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return <div className="metric-card"><small>{label}</small><strong>{value}</strong></div>;
}
