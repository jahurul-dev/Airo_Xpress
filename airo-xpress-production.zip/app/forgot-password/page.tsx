"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";

export default function ForgotPasswordPage() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setMessage(""); setError("");
    const email = new FormData(event.currentTarget).get("email");
    const response = await fetch("/api/auth/forgot-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    const data = await response.json();
    if (!response.ok) setError(data.error ?? "Could not send reset email");
    else setMessage(data.message);
  }
  return <section className="auth-page"><div className="auth-card"><span className="eyebrow">ACCOUNT SUPPORT</span><h1>Reset your password</h1><p>We’ll email you a secure, one-time reset link.</p>
    <form onSubmit={submit}><div className="form-field"><label htmlFor="email">Email address</label><input id="email" name="email" type="email" required /></div>
      {error && <div className="notice notice-error">{error}</div>}{message && <div className="notice notice-success">{message}</div>}
      <button className="button button-primary">Send reset link <span>→</span></button></form>
    <div className="auth-switch"><Link href="/login">Back to sign in</Link></div>
  </div></section>;
}
