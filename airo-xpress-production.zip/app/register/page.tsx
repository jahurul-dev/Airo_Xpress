import { AuthForm } from "@/components/AuthForm";
import { Suspense } from "react";
export const metadata = { title: "Create an account" };
export default function RegisterPage() { return <Suspense fallback={<div className="page-loading">Loading…</div>}><AuthForm mode="register" /></Suspense>; }
