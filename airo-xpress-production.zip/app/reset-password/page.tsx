"use client";

import Link from "next/link";
import { FormEvent, Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

function ResetPasswordForm() {
  const params = useSearchParams();
  const queryToken = params.get("token") ?? "";
  const [token] = useState(queryToken);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    const url = new URL(window.location.href);
    if (!url.searchParams.has("token")) return;
    url.searchParams.delete("token");
    window.history.replaceState(window.history.state, "", `${url.pathname}${url.search}${url.hash}`);
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setMessage("");
    const password = new FormData(event.currentTarget).get("password");
    const response = await fetch("/api/auth/reset-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, password }) });
    const data = await response.json();
    if (!response.ok) setError(data.error ?? "Could not reset password");
    else setMessage("Password reset. You can now sign in.");
  }
  return <section className="auth-page"><div className="auth-card"><span className="eyebrow">ACCOUNT SUPPORT</span><h1>Choose a new password</h1><p>Use at least 10 characters for your new password.</p>
    <form onSubmit={submit}><div className="form-field"><label htmlFor="password">New password</label><input id="password" name="password" type="password" minLength={10} maxLength={128} required /></div>
      {error && <div className="notice notice-error">{error}</div>}{message && <div className="notice notice-success">{message}</div>}
      <button className="button button-primary" disabled={!token}>Reset password <span>→</span></button></form>
    {message && <div className="auth-switch"><Link href="/login">Sign in</Link></div>}
  </div></section>;
}

export default function ResetPasswordPage() {
  return <Suspense fallback={<div className="auth-page">Loading…</div>}><ResetPasswordForm /></Suspense>;
}
