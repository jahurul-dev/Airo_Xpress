import { Marketplace } from "@/components/Marketplace";
import { Suspense } from "react";

export const metadata = { title: "Shop all" };

export default function ShopPage() {
  return <Suspense fallback={<div className="container page-loading">Loading the collection…</div>}><Marketplace /></Suspense>;
}
