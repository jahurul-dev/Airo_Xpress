import type { Metadata } from "next";
import { ProductDetails } from "@/components/ProductDetails";
import { db } from "@/lib/db";
import { getAppUrl } from "@/lib/app-url";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = await db.product.findFirst({
    where: { slug, isActive: true },
    include: { images: { orderBy: { position: "asc" }, take: 1 } }
  });
  if (!product) return { title: "Product not found", robots: { index: false, follow: false } };

  const description = product.description.replace(/\s+/g, " ").trim().slice(0, 180);
  const url = `${getAppUrl()}/product/${encodeURIComponent(product.slug)}`;
  const image = product.images[0]?.url;
  return {
    title: product.name,
    description,
    alternates: { canonical: url },
    openGraph: {
      type: "website",
      title: product.name,
      description,
      url,
      ...(image ? { images: [{ url: image, alt: product.name }] } : {})
    },
    twitter: {
      card: image ? "summary_large_image" : "summary",
      title: product.name,
      description,
      ...(image ? { images: [image] } : {})
    },
    other: {
      "product:price:amount": Number(product.price).toFixed(2),
      "product:price:currency": "BDT"
    }
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <ProductDetails slug={slug} />;
}
