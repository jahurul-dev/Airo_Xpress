import { AuthForm } from "@/components/AuthForm";
import { Suspense } from "react";
export const metadata = { title: "Sign in" };
export default function LoginPage() { return <Suspense fallback={<div className="page-loading">Loading…</div>}><AuthForm mode="login" /></Suspense>; }
