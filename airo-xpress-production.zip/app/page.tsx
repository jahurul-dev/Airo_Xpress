import { Marketplace } from "@/components/Marketplace";
import { Suspense } from "react";

export default function HomePage() {
  return <Suspense fallback={<div className="container page-loading">Loading the collection…</div>}><Marketplace home /></Suspense>;
}
