"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type Order = { id: string; orderNumber: string; status: string; paymentMethod: string; total: string | number; createdAt: string; items: { productName: string; quantity: number }[] };

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState("");
  const [placed, setPlaced] = useState<string | null>(null);
  useEffect(() => {
    fetch("/api/orders").then(async (response) => {
      const data = await response.json();
      if (response.status === 401) { window.location.href = "/login?next=/account/orders"; return; }
      if (!response.ok) throw new Error(data.error ?? "Could not load orders");
      setOrders(data.orders);
    }).catch((reason: Error) => setError(reason.message));
  }, []);
  useEffect(() => {
    setPlaced(new URLSearchParams(window.location.search).get("placed"));
  }, []);
  return <div className="container content-page"><div className="page-title"><span className="eyebrow">HERE FOR THE GOOD STUFF</span><h1>Your orders</h1></div>
    {placed && <div className="notice notice-success">Order {placed} placed successfully. You can follow its status here.</div>}
    <div className="account-layout"><nav className="account-nav"><Link href="/account">Overview</Link><Link href="/account/orders">Order history</Link><Link href="/vendor">Seller centre</Link></nav>
      <section className="account-panel"><h2>Order history</h2>{error && <div className="notice notice-error">{error}</div>}
        {!orders.length && !error ? <div className="empty-state"><h3>No orders yet</h3><p>Your next favourite is waiting.</p><Link href="/shop" className="button button-primary">Explore the shop</Link></div> :
          <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id}><td>{order.orderNumber}</td><td>{new Date(order.createdAt).toLocaleDateString()}</td><td>{order.items.length}</td><td>৳{Number(order.total).toLocaleString("en-BD")}</td><td>{order.paymentMethod}</td><td><span className="status-pill">{order.status}</span></td></tr>)}</tbody></table></div>}
      </section></div>
  </div>;
}
