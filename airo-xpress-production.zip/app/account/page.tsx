import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "My account" };

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/account");
  return <div className="container content-page"><div className="page-title"><span className="eyebrow">YOUR AIRO SPACE</span><h1>Hello, {user.name.split(" ")[0]}</h1></div>
    <div className="account-layout"><nav className="account-nav"><Link href="/account">Overview</Link><Link href="/account/orders">Order history</Link><Link href="/vendor">Seller centre</Link>{user.role === "ADMIN" && <Link href="/admin">Admin dashboard</Link>}</nav>
      <section className="account-panel"><h2>Your account</h2><p>Signed in as <b>{user.name}</b> ({user.email})</p><p className="muted-copy">Your orders, saved details and seller tools are all in one place.</p><Link className="button button-primary" href="/account/orders">View my orders <span>→</span></Link></section></div>
  </div>;
}
