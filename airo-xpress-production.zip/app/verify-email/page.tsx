"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

function VerifyEmailForm() {
  const queryToken = useSearchParams().get("token") ?? "";
  const [token] = useState(queryToken);
  const [message, setMessage] = useState("Verifying your email…");
  useEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.has("token")) {
      url.searchParams.delete("token");
      window.history.replaceState(window.history.state, "", `${url.pathname}${url.search}${url.hash}`);
    }
    if (!token) { setMessage("Verification link is invalid or expired."); return; }
    fetch("/api/auth/verify-email", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }) })
      .then(async (response) => {
        const data = await response.json();
        setMessage(response.ok ? "Your email has been verified." : data.error ?? "Verification failed.");
      }).catch(() => setMessage("Verification could not be completed. Please try again."));
  }, [token]);
  return <section className="auth-page"><div className="auth-card"><span className="eyebrow">AIRO XPRESS ACCOUNT</span><h1>Email verification</h1><p>{message}</p><Link className="button button-primary" href="/account">Continue <span>→</span></Link></div></section>;
}

export default function VerifyEmailPage() {
  return <Suspense fallback={<div className="auth-page">Verifying…</div>}><VerifyEmailForm /></Suspense>;
}
