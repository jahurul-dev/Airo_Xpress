import assert from "node:assert/strict";
import { test } from "node:test";
import { Coupon, PaymentMethod, Prisma } from "@prisma/client";
import { slugify } from "../lib/http";
import { getAppUrl } from "../lib/app-url";
import { csvCell } from "../lib/csv";
import { getSafeReturnPath } from "../lib/redirect";
import { getPaymentGateway } from "../lib/payments";
import { calculateCouponDiscount, couponIsAvailable, toMinorUnits } from "../lib/checkout";
import { getPurchaseEventId, shouldTrackMetaPageView, trackMetaEvent, trackPurchaseOnce } from "../lib/meta-pixel";
import { getMetaConversionsStatus } from "../lib/meta-conversions";
import { getImageDeletionPublicId } from "../lib/uploads";
import { getOrderCustomer } from "../lib/order-customer";
import locationData from "../public/data/bangladesh-locations.json";

test("slugify creates readable URL-safe slugs", () => {
  assert.equal(slugify("Home & Kitchen — New!"), "home-kitchen-new");
  assert.equal(slugify("  AIRO XPRESS  "), "airo-xpress");
});

test("production email links require a canonical HTTPS application URL", () => {
  const originalAppUrl = process.env.APP_URL;
  const originalNodeEnv = process.env.NODE_ENV;
  const originalVercel = process.env.VERCEL;
  Reflect.set(process.env, "NODE_ENV", "production");
  delete process.env.APP_URL;
  try {
    assert.throws(() => getAppUrl("https://attacker.example"), /APP_URL must be configured/);
    process.env.APP_URL = "http://shop.example";
    assert.throws(() => getAppUrl(), /must use HTTPS/);
    process.env.APP_URL = "http://localhost:3000";
    process.env.VERCEL = "1";
    assert.throws(() => getAppUrl(), /public HTTPS deployment URL/);
    delete process.env.VERCEL;
    process.env.APP_URL = "https://shop.example";
    assert.equal(getAppUrl(), "https://shop.example");
  } finally {
    if (originalAppUrl === undefined) delete process.env.APP_URL;
    else process.env.APP_URL = originalAppUrl;
    if (originalNodeEnv === undefined) Reflect.deleteProperty(process.env, "NODE_ENV");
    else Reflect.set(process.env, "NODE_ENV", originalNodeEnv);
    if (originalVercel === undefined) delete process.env.VERCEL;
    else process.env.VERCEL = originalVercel;
  }
});

test("CSV cells neutralize spreadsheet formulas after leading whitespace", () => {
  assert.equal(csvCell(" \t=1+1"), '"\' \t=1+1"');
  assert.equal(csvCell("@SUM(A1:A2)"), '"\'@SUM(A1:A2)"');
  assert.equal(csvCell(-12), '"-12"');
  assert.equal(csvCell('safe "value"'), '"safe ""value"""');
});

test("login return paths stay on the application origin", () => {
  assert.equal(getSafeReturnPath("/account/orders?placed=AX-1#latest", "https://shop.example"), "/account/orders?placed=AX-1#latest");
  assert.equal(getSafeReturnPath("//attacker.example", "https://shop.example"), "/account");
  assert.equal(getSafeReturnPath("/\\\\attacker.example", "https://shop.example"), "/account");
  assert.equal(getSafeReturnPath("https://attacker.example", "https://shop.example"), "/account");
});

test("payment gateways fail closed until provider adapters are configured", () => {
  assert.throws(() => getPaymentGateway(PaymentMethod.COD), /does not use a gateway/);
  assert.throws(() => getPaymentGateway(PaymentMethod.BKASH), /unavailable|adapter is not implemented/);
  assert.throws(() => getPaymentGateway(PaymentMethod.NAGAD), /unavailable|adapter is not implemented/);
  assert.throws(() => getPaymentGateway(PaymentMethod.CARD), /unavailable|adapter is not implemented/);
});

test("checkout money calculations preserve decimal precision", () => {
  assert.equal(toMinorUnits(new Prisma.Decimal("19.99")), 1999);
});

test("coupon availability and discount honor the configured limits", () => {
  const coupon: Coupon = {
    id: "coupon-1", code: "SAVE10", percentOff: 10, amountOff: null,
    minSubtotal: new Prisma.Decimal("50"), expiresAt: null, maxUses: 2,
    uses: 1, isActive: true, createdAt: new Date()
  };
  assert.equal(couponIsAvailable(coupon, 10000), true);
  assert.equal(calculateCouponDiscount(coupon, 10000), 1000);
  assert.equal(couponIsAvailable(coupon, 4999), false);
  assert.equal(couponIsAvailable({ ...coupon, uses: 2 }, 10000), false);
});

test("Bangladesh location data contains 64 uniquely named districts with upazilas", () => {
  assert.equal(locationData.districts.length, 64);
  assert.equal(new Set(locationData.districts.map((district) => district.name.toLowerCase())).size, 64);
  assert.ok(locationData.districts.every((district) => district.upazilas.length > 0));
});

test("Meta Pixel ignores invalid IDs and sends no event when disabled", () => {
  const originalPixelId = process.env.NEXT_PUBLIC_META_PIXEL_ID;
  process.env.NEXT_PUBLIC_META_PIXEL_ID = "not-a-pixel-id";
  try {
    assert.equal(trackMetaEvent("PageView"), false);
  } finally {
    if (originalPixelId === undefined) delete process.env.NEXT_PUBLIC_META_PIXEL_ID;
    else process.env.NEXT_PUBLIC_META_PIXEL_ID = originalPixelId;
  }
});

test("Meta Pixel page views exclude token-bearing account pages", () => {
  assert.equal(shouldTrackMetaPageView("/reset-password"), false);
  assert.equal(shouldTrackMetaPageView("/verify-email"), false);
  assert.equal(shouldTrackMetaPageView("/shop"), true);
});

test("vendor image deletion only uses a public ID stored on its owned image", () => {
  assert.equal(getImageDeletionPublicId("VENDOR", null, "victim/image"), null);
  assert.equal(getImageDeletionPublicId("VENDOR", "owned/image", "victim/image"), "owned/image");
  assert.equal(getImageDeletionPublicId("ADMIN", null, "orphan/image"), "orphan/image");
});

test("admin order summaries fall back to guest contact snapshots", () => {
  const address = { recipient: "Test Customer", email: "guest@example.test", phone: "01712345678" };
  assert.deepEqual(getOrderCustomer(null, address), {
    name: "Test Customer", email: "guest@example.test", phone: "01712345678"
  });
  assert.deepEqual(getOrderCustomer({ name: "Account Customer", email: "account@example.test", phone: null }, address), {
    name: "Account Customer", email: "account@example.test", phone: "01712345678"
  });
});

test("Meta Pixel purchase events include a stable event ID and are sent once", () => {
  const originalPixelId = process.env.NEXT_PUBLIC_META_PIXEL_ID;
  const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window");
  const calls: unknown[][] = [];
  process.env.NEXT_PUBLIC_META_PIXEL_ID = "123456789012345";
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: { fbq: (...args: unknown[]) => calls.push(args) }
  });
  try {
    const parameters = { value: 100, currency: "BDT" };
    assert.equal(trackPurchaseOnce("AX-TEST-1", parameters), true);
    assert.equal(trackPurchaseOnce("AX-TEST-1", parameters), false);
    assert.equal(calls.length, 1);
    assert.equal(getPurchaseEventId("AX-TEST-1"), "purchase-AX-TEST-1");
    assert.deepEqual(calls[0], ["track", "Purchase", parameters, { eventID: getPurchaseEventId("AX-TEST-1") }]);
  } finally {
    if (originalPixelId === undefined) delete process.env.NEXT_PUBLIC_META_PIXEL_ID;
    else process.env.NEXT_PUBLIC_META_PIXEL_ID = originalPixelId;
    if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow);
    else Reflect.deleteProperty(globalThis, "window");
  }
});

test("Meta Conversions API status does not expose credentials", () => {
  const originalPixelId = process.env.NEXT_PUBLIC_META_PIXEL_ID;
  const originalToken = process.env.META_CAPI_ACCESS_TOKEN;
  const originalVersion = process.env.META_CAPI_GRAPH_API_VERSION;
  const originalAppUrl = process.env.APP_URL;
  delete process.env.NEXT_PUBLIC_META_PIXEL_ID;
  delete process.env.META_CAPI_ACCESS_TOKEN;
  delete process.env.META_CAPI_GRAPH_API_VERSION;
  try {
    assert.deepEqual(getMetaConversionsStatus(), {
      pixelConfigured: false,
      conversionsApiConfigured: false,
      graphApiVersionConfigured: false,
      testEventCodeConfigured: false
    });
  } finally {
    if (originalPixelId === undefined) delete process.env.NEXT_PUBLIC_META_PIXEL_ID;
    else process.env.NEXT_PUBLIC_META_PIXEL_ID = originalPixelId;
    if (originalToken === undefined) delete process.env.META_CAPI_ACCESS_TOKEN;
    else process.env.META_CAPI_ACCESS_TOKEN = originalToken;
    if (originalVersion === undefined) delete process.env.META_CAPI_GRAPH_API_VERSION;
    else process.env.META_CAPI_GRAPH_API_VERSION = originalVersion;
    if (originalAppUrl === undefined) delete process.env.APP_URL;
    else process.env.APP_URL = originalAppUrl;
  }
});
