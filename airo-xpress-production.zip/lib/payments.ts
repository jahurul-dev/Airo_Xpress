import { PaymentMethod } from "@prisma/client";

export type PaymentStart = { redirectUrl: string; providerReference: string };

export interface PaymentGateway {
  start(orderNumber: string, amount: number): Promise<PaymentStart>;
  verify(providerReference: string): Promise<{ paid: boolean; transactionId: string }>;
}

export class PaymentUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PaymentUnavailableError";
  }
}

export function getPaymentGateway(method: PaymentMethod): PaymentGateway {
  if (method === PaymentMethod.COD) {
    throw new PaymentUnavailableError("Cash on delivery does not use a gateway.");
  }
  const configured =
    method === PaymentMethod.BKASH
      ? Boolean(process.env.BKASH_APP_KEY && process.env.BKASH_APP_SECRET && process.env.BKASH_USERNAME && process.env.BKASH_PASSWORD)
      : method === PaymentMethod.NAGAD
        ? Boolean(process.env.NAGAD_MERCHANT_ID && process.env.NAGAD_MERCHANT_PRIVATE_KEY)
        : Boolean(process.env.SSL_COMMERZ_STORE_ID && process.env.SSL_COMMERZ_STORE_PASSWORD);
  if (!configured) {
    throw new PaymentUnavailableError(`${method} payments are unavailable: official merchant credentials are not configured.`);
  }
  throw new PaymentUnavailableError(`${method} gateway adapter is not implemented. Do not accept payment until the official provider adapter and callback verification are configured.`);
}
