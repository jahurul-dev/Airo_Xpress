type MetaPixelCall = (
  command: "track",
  eventName: string,
  parameters?: Record<string, unknown>,
  options?: { eventID?: string }
) => void;

declare global {
  interface Window {
    fbq?: MetaPixelCall;
  }
}

const trackedPurchaseIds = new Set<string>();
const PURCHASE_STORAGE_PREFIX = "airo-meta-purchase:";

export function getMetaPixelId() {
  const pixelId = process.env.NEXT_PUBLIC_META_PIXEL_ID?.trim();
  return pixelId && /^\d{5,20}$/.test(pixelId) ? pixelId : null;
}

export function shouldTrackMetaPageView(pathname: string) {
  return pathname !== "/reset-password" && pathname !== "/verify-email";
}

export function getPurchaseEventId(orderNumber: string) {
  return `purchase-${orderNumber}`;
}

export function trackMetaEvent(
  eventName: string,
  parameters?: Record<string, unknown>,
  eventId?: string
) {
  if (!getMetaPixelId() || typeof window === "undefined" || !window.fbq) return false;
  try {
    window.fbq("track", eventName, parameters, eventId ? { eventID: eventId } : undefined);
    return true;
  } catch (error) {
    console.error("Meta Pixel event could not be sent.", error);
    return false;
  }
}

export function trackPurchaseOnce(orderNumber: string, parameters: Record<string, unknown>) {
  if (trackedPurchaseIds.has(orderNumber)) return false;
  const storageKey = `${PURCHASE_STORAGE_PREFIX}${orderNumber}`;
  try {
    if (window.localStorage?.getItem(storageKey)) {
      trackedPurchaseIds.add(orderNumber);
      return false;
    }
  } catch {
    // Browser storage may be unavailable; in-memory deduplication still applies.
  }
  const tracked = trackMetaEvent("Purchase", parameters, getPurchaseEventId(orderNumber));
  if (tracked) {
    trackedPurchaseIds.add(orderNumber);
    try {
      window.localStorage?.setItem(storageKey, "1");
    } catch {
      // The event was sent; storage failure must not cause another attempt this session.
    }
  }
  return tracked;
}
