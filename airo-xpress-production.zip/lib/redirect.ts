export function getSafeReturnPath(destination: string | null, origin: string) {
  if (!destination?.startsWith("/")) return "/account";

  const target = new URL(destination, origin);
  if (target.origin !== origin) return "/account";

  return `${target.pathname}${target.search}${target.hash}`;
}
