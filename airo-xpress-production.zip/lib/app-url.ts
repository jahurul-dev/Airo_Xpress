import { ApiError } from "@/lib/errors";

export function getAppUrl(fallbackUrl?: string) {
  const configuredUrl = process.env.APP_URL;
  if (!configuredUrl) {
    if (process.env.NODE_ENV === "production") {
      throw new ApiError("APP_URL must be configured in production.", 503);
    }
    return fallbackUrl ? new URL(fallbackUrl).origin : "http://localhost:3000";
  }

  let url: URL;
  try {
    url = new URL(configuredUrl);
  } catch {
    throw new ApiError("APP_URL must be a valid absolute URL.", 503);
  }

  const isLocalhost = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (process.env.NODE_ENV === "production" && url.protocol !== "https:" && !isLocalhost) {
    throw new ApiError("APP_URL must use HTTPS in production.", 503);
  }
  if (process.env.VERCEL === "1" && process.env.NODE_ENV === "production" && isLocalhost) {
    throw new ApiError("APP_URL must be the public HTTPS deployment URL on Vercel.", 503);
  }
  if (url.username || url.password || url.search || url.hash) {
    throw new ApiError("APP_URL must not contain credentials, a query, or a fragment.", 503);
  }

  return url.origin;
}
