import type { Prisma } from "@prisma/client";

type UserSummary = { name: string; email: string; phone: string | null } | null;

function addressString(address: Prisma.JsonValue, key: string) {
  if (!address || typeof address !== "object" || Array.isArray(address)) return null;
  const value = address[key];
  return typeof value === "string" ? value : null;
}

export function getOrderCustomer(user: UserSummary, address: Prisma.JsonValue) {
  return {
    name: user?.name ?? addressString(address, "recipient") ?? "Guest checkout",
    email: user?.email ?? addressString(address, "email") ?? "",
    phone: user?.phone ?? addressString(address, "phone")
  };
}
