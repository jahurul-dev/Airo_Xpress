import { Coupon } from "@prisma/client";

type DecimalInput = number | string | { toString(): string };

export function toMinorUnits(amount: DecimalInput) {
  return Math.round(Number(amount) * 100);
}

export function fromMinorUnits(amount: number) {
  return amount / 100;
}

export function calculateCouponDiscount(coupon: Coupon, subtotalMinor: number) {
  if (coupon.percentOff !== null) {
    return Math.min(subtotalMinor, Math.round(subtotalMinor * coupon.percentOff / 100));
  }
  return Math.min(subtotalMinor, toMinorUnits(coupon.amountOff ?? 0));
}

export function couponIsAvailable(
  coupon: Coupon | null,
  subtotalMinor: number,
  now = new Date()
): coupon is Coupon {
  return Boolean(coupon &&
    coupon.isActive &&
    (!coupon.expiresAt || coupon.expiresAt > now) &&
    (coupon.maxUses === null || coupon.uses < coupon.maxUses) &&
    subtotalMinor >= toMinorUnits(coupon.minSubtotal) &&
    (coupon.percentOff === null || (coupon.percentOff >= 1 && coupon.percentOff <= 100)) &&
    (coupon.percentOff !== null || (coupon.amountOff !== null && Number(coupon.amountOff) > 0)));
}
