import { ApiError } from "@/lib/http";

export async function sendTransactionalEmail(to: string, subject: string, html: string) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!apiKey || !from) throw new ApiError("Email delivery is unavailable: configure RESEND_API_KEY and EMAIL_FROM.", 503);

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: [to], subject, html })
  });
  if (!response.ok) {
    console.error("Email provider rejected the message", { status: response.status });
    throw new ApiError("Email provider could not deliver the message.", 502);
  }
}
