const formulaPrefix = /^[\s\u0000-\u001f\u007f-\u009f]*[=+\-@]/u;

export function csvCell(value: unknown) {
  const text = value === null || value === undefined ? "" : String(value);
  const safeText = typeof value === "string" && formulaPrefix.test(text) ? `'${text}` : text;
  return `"${safeText.replaceAll('"', '""')}"`;
}
