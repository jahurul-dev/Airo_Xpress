import locations from "@/public/data/bangladesh-locations.json";

export type BangladeshDistrict = (typeof locations.districts)[number];

export function getDistrict(name: string) {
  return locations.districts.find((district) => district.name.toLocaleLowerCase() === name.trim().toLocaleLowerCase());
}

export function isValidDistrictUpazila(districtName: string, upazilaName: string) {
  const district = getDistrict(districtName);
  return Boolean(district?.upazilas.some((upazila) => upazila.name.toLocaleLowerCase() === upazilaName.trim().toLocaleLowerCase()));
}

export const deliveryTiers = [
  { code: "INSIDE_DHAKA", cityPattern: "inside_dhaka", name: "Inside Dhaka", defaultFee: 70 },
  { code: "SUBURBAN_DHAKA", cityPattern: "suburban_dhaka", name: "Suburban Dhaka", defaultFee: 100 },
  { code: "OUTSIDE_DHAKA", cityPattern: "outside_dhaka", name: "Outside Dhaka", defaultFee: 120 }
] as const;
