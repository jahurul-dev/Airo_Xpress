import { UserRole } from "@prisma/client";

export function getImageDeletionPublicId(
  role: UserRole,
  storedPublicId: string | null | undefined,
  requestedPublicId: unknown
) {
  if (storedPublicId) return storedPublicId;
  return role === UserRole.ADMIN && typeof requestedPublicId === "string" ? requestedPublicId : null;
}
