import { createHash } from "node:crypto";
import { Prisma } from "@prisma/client";
import { getAppUrl } from "@/lib/app-url";
import { getMetaPixelId, getPurchaseEventId } from "@/lib/meta-pixel";
import { getOrderCustomer } from "@/lib/order-customer";

type PurchaseOrder = {
  orderNumber: string;
  total: Prisma.Decimal | number | string;
  items: { productId: string; quantity: number; unitPrice: Prisma.Decimal | number | string }[];
};

function getConfiguration() {
  const pixelId = getMetaPixelId();
  const accessToken = process.env.META_CAPI_ACCESS_TOKEN?.trim();
  const graphApiVersion = process.env.META_CAPI_GRAPH_API_VERSION?.trim();
  const testEventCode = process.env.META_CAPI_TEST_EVENT_CODE?.trim();
  const validGraphApiVersion = graphApiVersion && /^v\d+\.\d+$/.test(graphApiVersion)
    ? graphApiVersion
    : null;
  const validTestEventCode = testEventCode && /^[A-Za-z0-9_-]{1,100}$/.test(testEventCode)
    ? testEventCode
    : null;

  return {
    pixelId,
    accessToken,
    graphApiVersion: validGraphApiVersion,
    testEventCode: validTestEventCode,
    configured: Boolean(pixelId && accessToken && validGraphApiVersion && process.env.APP_URL?.trim())
  };
}

export function getMetaConversionsStatus() {
  const configuration = getConfiguration();
  return {
    pixelConfigured: Boolean(configuration.pixelId),
    conversionsApiConfigured: configuration.configured,
    graphApiVersionConfigured: Boolean(configuration.graphApiVersion),
    testEventCodeConfigured: Boolean(configuration.testEventCode)
  };
}

function hash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function normalizePhone(value: unknown) {
  if (typeof value !== "string") return null;
  const digits = value.replace(/\D/g, "");
  if (!digits) return null;
  return digits.startsWith("880") ? digits : digits.startsWith("0") ? `88${digits}` : digits;
}

function getDeliveryPhone(address: Prisma.JsonValue) {
  if (!address || typeof address !== "object" || Array.isArray(address)) return null;
  return normalizePhone(address.phone);
}

export async function sendMetaPurchaseConversion(
  order: PurchaseOrder,
  email: string | null,
  deliveryAddress: Prisma.JsonValue,
  eventSourcePath = "/checkout",
  eventTime = new Date()
) {
  const configuration = getConfiguration();
  if (!configuration.configured || !configuration.pixelId || !configuration.accessToken ||
    !configuration.graphApiVersion) return false;

  try {
    const phone = getDeliveryPhone(deliveryAddress);
    const customer = getOrderCustomer(null, deliveryAddress);
    const userData: Record<string, string[]> = {};
    if (email?.trim()) userData.em = [hash(email.trim().toLowerCase())];
    if (phone) userData.ph = [hash(phone)];
    else if (customer.phone) userData.ph = [hash(customer.phone.replace(/\D/g, ""))];

    const payload = {
      data: [{
        event_name: "Purchase",
        event_time: Math.floor(eventTime.getTime() / 1000),
        event_id: getPurchaseEventId(order.orderNumber),
        action_source: "website",
        event_source_url: new URL(eventSourcePath, getAppUrl()).toString(),
        user_data: userData,
        custom_data: {
          content_ids: order.items.map((item) => item.productId),
          contents: order.items.map((item) => ({
            id: item.productId,
            quantity: item.quantity,
            item_price: Number(item.unitPrice)
          })),
          content_type: "product",
          currency: "BDT",
          order_id: order.orderNumber,
          value: Number(order.total)
        }
      }],
      ...(configuration.testEventCode ? { test_event_code: configuration.testEventCode } : {})
    };

    const endpoint = new URL(
      `https://graph.facebook.com/${configuration.graphApiVersion}/${configuration.pixelId}/events`
    );
    endpoint.searchParams.set("access_token", configuration.accessToken);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(5000),
      cache: "no-store"
    });
    if (!response.ok) {
      console.error("Meta Conversions API rejected a Purchase event.", { status: response.status });
      return false;
    }
    return true;
  } catch (error) {
    console.error("Meta Conversions API request failed.", {
      name: error instanceof Error ? error.name : "UnknownError"
    });
    return false;
  }
}
