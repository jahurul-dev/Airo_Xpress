"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { trackMetaEvent, trackPurchaseOnce } from "@/lib/meta-pixel";

type Product = {
  id: string; name: string; slug: string; description: string; price: string | number;
  compareAtPrice?: string | number | null; stock: number; brand?: string | null; rating: number;
  reviewCount: number; images: { url: string; alt?: string | null }[];
  category: { name: string }; reviews: { id: string; rating: number; comment?: string | null; user: { name: string } }[];
};
type Location = { name: string; nameBn: string; upazilas: { name: string; nameBn: string }[] };
type DeliveryOption = {
  type: "INSIDE_DHAKA" | "SUBURBAN_DHAKA" | "OUTSIDE_DHAKA";
  name: string; fee: number; configured: boolean;
};

const money = (amount: number) => `৳${amount.toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export function ProductDetails({ slug }: { slug: string }) {
  const [product, setProduct] = useState<Product | null>(null);
  const [error, setError] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState("");
  const [locations, setLocations] = useState<Location[]>([]);
  const [deliveryOptions, setDeliveryOptions] = useState<DeliveryOption[]>([]);
  const [district, setDistrict] = useState("");
  const [upazila, setUpazila] = useState("");
  const [deliveryTier, setDeliveryTier] = useState<DeliveryOption["type"]>("OUTSIDE_DHAKA");
  const [orderError, setOrderError] = useState("");
  const [orderSuccess, setOrderSuccess] = useState("");
  const [orderBusy, setOrderBusy] = useState(false);
  const checkoutRequestId = useRef("");
  const checkoutTracked = useRef(false);
  const orderFormRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    fetch(`/api/products/${encodeURIComponent(slug)}`).then(async (response) => {
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Product could not be loaded");
      setProduct(data.product);
    }).catch((reason: Error) => setError(reason.message));
  }, [slug]);

  useEffect(() => {
    Promise.all([
      fetch("/data/bangladesh-locations.json").then(async (response) => {
        if (!response.ok) throw new Error("Bangladesh location data could not be loaded.");
        const data = await response.json();
        return data.districts as Location[];
      }),
      fetch("/api/delivery-zones").then(async (response) => {
        if (!response.ok) throw new Error("Delivery fees could not be loaded.");
        const data = await response.json();
        return data.options as DeliveryOption[];
      })
    ]).then(([locationData, deliveryData]) => {
      setLocations(locationData);
      setDeliveryOptions(deliveryData);
    }).catch((reason: Error) => setOrderError(reason.message));
  }, []);

  useEffect(() => {
    if (!product) return;
    trackMetaEvent("ViewContent", {
      content_ids: [product.id],
      content_name: product.name,
      content_type: "product",
      currency: "BDT",
      value: Number(product.price)
    });
  }, [product]);

  async function addToCart() {
    if (!product) return;
    const response = await fetch("/api/cart", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, quantity })
    });
    const data = await response.json();
    if (response.status === 401) {
      window.location.href = "/login?next=/cart";
    } else if (!response.ok) {
      setMessage(data.error ?? "Could not add this product");
    } else {
      trackMetaEvent("AddToCart", {
        content_ids: [product.id],
        content_type: "product",
        currency: "BDT",
        value: Number(product.price) * quantity
      });
      setMessage("Added to your cart");
    }
  }

  function focusOrderForm() {
    if (!checkoutTracked.current && product) {
      checkoutTracked.current = true;
      trackMetaEvent("InitiateCheckout", {
        content_ids: [product.id],
        contents: [{ id: product.id, quantity }],
        content_type: "product",
        currency: "BDT",
        value: Number(product.price) * quantity
      });
    }
    orderFormRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    orderFormRef.current?.querySelector<HTMLInputElement>("#guest-recipient")?.focus({ preventScroll: true });
  }

  function changeDistrict(value: string) {
    setDistrict(value);
    setUpazila("");
    setDeliveryTier(value === "Dhaka" ? "INSIDE_DHAKA" : "OUTSIDE_DHAKA");
  }

  async function placeGuestOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!product) return;
    setOrderBusy(true);
    setOrderError("");
    const form = new FormData(event.currentTarget);
    if (!checkoutTracked.current) {
      checkoutTracked.current = true;
      trackMetaEvent("InitiateCheckout", {
        content_ids: [product.id],
        contents: [{ id: product.id, quantity }],
        content_type: "product",
        currency: "BDT",
        value: Number(product.price) * quantity
      });
    }
    const payload = {
      checkoutRequestId: checkoutRequestId.current || (checkoutRequestId.current = crypto.randomUUID()),
      productId: product.id,
      quantity,
      address: {
        recipient: form.get("recipient"),
        phone: form.get("phone"),
        district,
        upazila,
        addressLine: form.get("addressLine"),
        deliveryInstructions: form.get("deliveryInstructions") || undefined,
        postalCode: form.get("postalCode") || undefined
      },
      deliveryTier
    };
    try {
      const response = await fetch("/api/guest-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Could not place your order.");
      trackPurchaseOnce(data.order.orderNumber, {
        content_ids: [product.id],
        contents: [{ id: product.id, quantity, item_price: price }],
        content_type: "product",
        currency: "BDT",
        value: Number(data.order.total)
      });
      setOrderSuccess(data.order.orderNumber);
    } catch (reason) {
      setOrderError(reason instanceof Error ? reason.message : "Could not place your order.");
    } finally {
      setOrderBusy(false);
    }
  }

  if (error) return <div className="container content-page"><div className="page-title"><Link className="text-link" href="/shop">← Back to shop</Link></div><div className="notice notice-error">{error}</div></div>;
  if (!product) return <div className="container page-loading">Loading product…</div>;
  const price = Number(product.price);
  const selectedDistrict = locations.find((item) => item.name === district);
  const selectedDelivery = deliveryOptions.find((option) => option.type === deliveryTier);

  return <div className="container">
    <div className="page-title"><Link className="text-link" href="/shop">← Back to shopping</Link></div>
    <section className="product-detail">
      <div className="detail-image">{product.images[0]?.url ? <Image src={product.images[0].url} alt={product.images[0].alt ?? product.name} fill unoptimized sizes="(max-width: 620px) 100vw, 50vw" /> : <span className="image-placeholder"><span>AIRO</span><small>Everyday essentials</small></span>}</div>
      <div className="detail-info">
        <span className="eyebrow">{product.category.name}{product.brand ? ` / ${product.brand}` : ""}</span>
        <h1>{product.name}</h1>
        <div className="detail-rating">★★★★★ <small>{product.rating.toFixed(1)} ({product.reviewCount} reviews)</small></div>
        <div className="detail-price">৳{price.toLocaleString("en-BD")}</div>
        {product.compareAtPrice && Number(product.compareAtPrice) > price && <span className="detail-compare">৳{Number(product.compareAtPrice).toLocaleString("en-BD")}</span>}
        <div className="detail-stock">{product.stock > 0 ? `${product.stock} in stock · Ready to ship` : "Currently out of stock"}</div>
        <p className="detail-description">{product.description}</p>
        <div className="quantity-row"><label htmlFor="quantity">Quantity</label><input id="quantity" type="number" min={1} max={Math.min(product.stock, 20)} value={quantity} onChange={(event) => setQuantity(Math.min(20, Math.max(1, Number(event.target.value))))} /><button className="button button-primary" disabled={product.stock < 1} onClick={() => addToCart()}>Add to cart <span>→</span></button><button className="button button-outline" disabled={product.stock < 1} onClick={focusOrderForm}>Order now</button></div>
        {message && <div className="notice notice-success">{message}</div>}
        <div className="specs"><b>A little more to know</b><p>Delivery charges are shown before you place your order.</p><p>Cash on delivery is available. Your details are used to fulfill this order.</p></div>
      </div>
    </section>
    <section className="account-panel" style={{ maxWidth: 720, margin: "0 auto 48px" }}>
      <div className="page-title"><span className="eyebrow">QUICK ORDER · CASH ON DELIVERY</span><h2>Order this product</h2></div>
      {orderSuccess ? (
        <div className="notice notice-success" role="status">
          Order {orderSuccess} was placed. An administrator will confirm it before dispatch; payment is due on delivery.
        </div>
      ) : (
        <form ref={orderFormRef} id="quick-order" onSubmit={placeGuestOrder}>
          <div className="form-field"><label htmlFor="guest-recipient">Customer full name</label><input id="guest-recipient" name="recipient" autoComplete="name" required minLength={2} maxLength={100} disabled={orderBusy} /></div>
          <div className="form-field"><label htmlFor="guest-phone">Mobile number</label><input id="guest-phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="01XXXXXXXXX or +8801XXXXXXXXX" required pattern="(?:\+?8801|01)[3-9][0-9]{8}" title="Enter a valid Bangladesh mobile number" disabled={orderBusy} /></div>
          <div className="form-field"><label htmlFor="guest-district">District</label><select id="guest-district" value={district} onChange={(event) => changeDistrict(event.target.value)} required disabled={orderBusy}><option value="">Select district</option>{locations.map((item) => <option key={item.name} value={item.name}>{item.name}{item.nameBn ? ` — ${item.nameBn}` : ""}</option>)}</select></div>
          <div className="form-field"><label htmlFor="guest-upazila">Upazila / Thana</label><select id="guest-upazila" value={upazila} onChange={(event) => setUpazila(event.target.value)} required disabled={orderBusy || !selectedDistrict}><option value="">Select upazila</option>{selectedDistrict?.upazilas.map((item) => <option key={item.name} value={item.name}>{item.name}{item.nameBn ? ` — ${item.nameBn}` : ""}</option>)}</select></div>
          <div className="form-field"><label htmlFor="guest-address">Complete delivery address</label><textarea id="guest-address" name="addressLine" autoComplete="street-address" placeholder="House, road, village and landmark" required minLength={5} maxLength={250} disabled={orderBusy} /></div>
          <div className="form-field"><label htmlFor="guest-instructions">Delivery instructions (optional)</label><textarea id="guest-instructions" name="deliveryInstructions" maxLength={500} disabled={orderBusy} /></div>
          <div className="form-field"><label htmlFor="guest-postal">Postal code (optional)</label><input id="guest-postal" name="postalCode" autoComplete="postal-code" maxLength={20} disabled={orderBusy} /></div>
          <div className="form-field"><label htmlFor="guest-delivery-tier">Delivery area</label><select id="guest-delivery-tier" value={deliveryTier} onChange={(event) => { const selected = deliveryOptions.find((option) => option.type === event.target.value); if (selected) setDeliveryTier(selected.type); }} required disabled={orderBusy}><option value="">Select delivery area</option>{deliveryOptions.map((option) => <option key={option.type} value={option.type} disabled={!option.configured}>{option.name} · {money(option.fee)}{!option.configured ? " (unavailable)" : ""}</option>)}</select></div>
          {selectedDelivery && <>
            <div className="summary-row"><span>Product subtotal</span><b>{money(price * quantity)}</b></div>
            <div className="summary-row"><span>Delivery · {selectedDelivery.name}</span><b>{money(selectedDelivery.fee)}</b></div>
            <div className="summary-row summary-total"><span>Total payable</span><b>{money(price * quantity + selectedDelivery.fee)}</b></div>
          </>}
          <p className="muted-copy">Delivery fee is verified by the server. No online payment is taken; this order uses cash on delivery.</p>
          {orderError && <div className="notice notice-error" role="alert">{orderError}</div>}
          <button className="button button-primary" disabled={orderBusy || product.stock < 1 || !selectedDelivery?.configured}>{orderBusy ? "Placing order…" : "Place cash-on-delivery order"}</button>
        </form>
      )}
    </section>
    <section className="content-page"><div className="section-heading"><div><span className="eyebrow">SHOPPER NOTES</span><h2>Reviews</h2></div></div>
      {product.reviews.length ? product.reviews.map((review) => <div className="account-panel" key={review.id}><b>{review.user.name}</b><span className="detail-rating"> · {"★".repeat(review.rating)}</span><p>{review.comment}</p></div>) : <p className="muted-copy">No reviews yet.</p>}
    </section>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
      "@context": "https://schema.org", "@type": "Product", name: product.name,
      description: product.description, sku: product.id, offers: {
        "@type": "Offer", priceCurrency: "BDT", price, availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock"
      }
    }).replace(/</g, "\\u003c") }} />
  </div>;
}
