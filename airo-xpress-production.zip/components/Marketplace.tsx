"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ProductCard, ProductSummary } from "@/components/ProductCard";

type Category = { id: string; name: string; slug: string };
type Banner = { id: string; title: string; description: string | null; imageUrl: string | null; linkUrl: string | null };
type Pagination = { page: number; pageSize: number; total: number; pages: number };

export function Marketplace({ home = false }: { home?: boolean }) {
  const router = useRouter();
  const params = useSearchParams();
  const [products, setProducts] = useState<ProductSummary[]>([]);
  const [pagination, setPagination] = useState<Pagination>({ page: 1, pageSize: 24, total: 0, pages: 0 });
  const [categories, setCategories] = useState<Category[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [newsletterMessage, setNewsletterMessage] = useState("");
  const [sort, setSort] = useState("newest");
  const category = params.get("category") ?? "";
  const query = params.get("q") ?? "";
  const page = Math.max(1, Number(params.get("page")) || 1);
  const minPrice = params.get("min") ?? "";
  const maxPrice = params.get("max") ?? "";

  useEffect(() => {
    setLoading(true);
    const search = new URLSearchParams({
      sort,
      page: String(page),
      ...(category ? { category } : {}),
      ...(query ? { q: query } : {}),
      ...(minPrice ? { min: minPrice } : {}),
      ...(maxPrice ? { max: maxPrice } : {})
    });
    Promise.all([
      fetch(`/api/products?${search}`).then(async (response) => {
        if (!response.ok) throw new Error("Products could not be loaded. Please try again.");
        return response.json();
      }),
      fetch("/api/categories").then(async (response) => {
        if (!response.ok) throw new Error("Categories could not be loaded.");
        return response.json();
      }),
      home ? fetch("/api/banners").then(async (response) => {
        if (!response.ok) throw new Error("Homepage promotions could not be loaded.");
        return response.json();
      }) : Promise.resolve({ banners: [] })
    ]).then(([productData, categoryData, bannerData]) => {
      setProducts(productData.products);
      setPagination(productData.pagination);
      setCategories(categoryData.categories);
      setBanners(bannerData.banners);
      setError("");
    }).catch((reason: Error) => setError(reason.message))
      .finally(() => setLoading(false));
  }, [category, home, maxPrice, minPrice, page, query, sort]);

  function applyPriceFilter(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const nextParams = new URLSearchParams(params.toString());
    nextParams.delete("page");
    for (const key of ["min", "max"]) {
      const value = String(form.get(key) ?? "").trim();
      if (value) nextParams.set(key, value);
      else nextParams.delete(key);
    }
    router.push(`/shop?${nextParams.toString()}`);
  }

  function goToPage(nextPage: number) {
    const nextParams = new URLSearchParams(params.toString());
    nextParams.set("page", String(nextPage));
    router.push(`/shop?${nextParams.toString()}`);
  }

  async function subscribe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const email = new FormData(event.currentTarget).get("email");
    const response = await fetch("/api/newsletter", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email })
    });
    const data = await response.json();
    setNewsletterMessage(data.message ?? data.error ?? "Could not save your signup.");
    if (response.ok) event.currentTarget.reset();
  }

  return (
    <div className="container marketplace">
      {home && <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-dot" /> THE EVERYDAY EDIT</span>
          <h1>Good finds.<br /><em>Good life.</em></h1>
          <p>Thoughtful picks for the way you live. Explore fresh finds from the brands you love, all in one place.</p>
          <Link className="button button-primary" href="/shop">Explore the collection <span>→</span></Link>
          <div className="hero-proof"><span className="proof-stars">★★★★★</span> Loved by shoppers across Bangladesh</div>
        </div>
        <div className="hero-art" aria-label="AIRO XPRESS featured collection">
          <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
          <div className="hero-center"><span>AX</span><small>THE DAILY<br />DISCOVERY</small></div>
          <div className="floating-tag tag-top">CURATED FOR YOU <span>✦</span></div>
          <div className="floating-tag tag-bottom"><b>01 / 04</b><span>THE NEW SEASON</span></div>
          <div className="hero-spark spark-one">✳</div><div className="hero-spark spark-two">✦</div>
        </div>
        <div className="hero-index"><span>01</span> / 04</div>
      </section>}

      {home && <section className="trust-row">
        <div><span className="trust-icon">✳</span><span><b>Thoughtfully picked</b><small>Quality finds, always</small></span></div>
        <div><span className="trust-icon">↗</span><span><b>Fast delivery</b><small>Across Bangladesh</small></span></div>
        <div><span className="trust-icon">♡</span><span><b>Easy returns</b><small>Shop with confidence</small></span></div>
        <div><span className="trust-icon">⌑</span><span><b>Secure checkout</b><small>Your details stay safe</small></span></div>
      </section>}

      {home && <section className="category-section">
        <div className="section-heading"><div><span className="eyebrow">FIND YOUR SOMETHING</span><h2>Shop by category</h2></div><Link href="/shop" className="text-link">View everything <span>→</span></Link></div>
        <div className="category-grid">
          {(categories.length ? categories : [
            { name: "Electronics", slug: "electronics" }, { name: "Fashion", slug: "fashion" },
            { name: "Home & Kitchen", slug: "home-kitchen" }, { name: "Beauty", slug: "beauty" }
          ]).slice(0, 4).map((item, index) => <Link key={item.slug} className={`category-tile category-tone-${index + 1}`} href={`/shop?category=${item.slug}`}>
            <span className="category-number">0{index + 1}</span><span className="category-illustration">{["◈", "◌", "⌂", "✿"][index % 4]}</span>
            <span className="category-name">{item.name}</span><span className="category-arrow">↗</span>
          </Link>)}
        </div>
      </section>}

      <section className="product-section">
        <div className="section-heading">
          <div><span className="eyebrow">{home ? "A FEW GOOD FINDS" : "THE AIRO COLLECTION"}</span><h2>{home ? "Picked for you" : query ? `Results for “${query}”` : "Shop all products"}</h2></div>
          <div className="product-controls">{!home && <>
            <form className="price-filter" onSubmit={applyPriceFilter}>
              <label>Min <input name="min" type="number" min="0" step="0.01" defaultValue={minPrice} aria-label="Minimum price" /></label>
              <label>Max <input name="max" type="number" min="0" step="0.01" defaultValue={maxPrice} aria-label="Maximum price" /></label>
              <button type="submit">Apply</button>
            </form>
            <label className="sort-control">Sort by <select value={sort} onChange={(event) => setSort(event.target.value)}><option value="newest">Newest</option><option value="popular">Popular</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option></select></label>
          </>}<Link href="/shop" className="text-link">See all <span>→</span></Link></div>
        </div>
        {error ? <div className="notice notice-error">{error}</div> : loading ? <div className="loading-grid">{[1, 2, 3, 4].map((n) => <div className="skeleton-card" key={n} />)}</div> :
          products.length ? <div className={`product-grid${home ? " home-product-grid" : ""}`}>{products.slice(0, home ? 8 : 24).map((product) => <ProductCard key={product.id} product={product} />)}</div> :
            <div className="empty-state"><span>⌕</span><h3>No products just yet</h3><p>New finds are on their way. Try another category or check back soon.</p><Link className="button button-outline" href="/shop">Browse all products</Link></div>}
        {!home && pagination.pages > 1 && <nav className="pagination" aria-label="Product pages">
          <button type="button" className="button button-outline" disabled={page <= 1} onClick={() => goToPage(page - 1)}>Previous</button>
          <span>Page {pagination.page} of {pagination.pages} · {pagination.total} products</span>
          <button type="button" className="button button-outline" disabled={page >= pagination.pages} onClick={() => goToPage(page + 1)}>Next</button>
        </nav>}
      </section>

      {home && (banners.length ? banners : [{ id: "default-promo", title: "Your next favourite is waiting.", description: "New finds, everyday essentials, and a little joy in every delivery.", imageUrl: null, linkUrl: "/shop" }]).map((banner) =>
        <section className="promo-band" key={banner.id} style={banner.imageUrl ? { backgroundImage: `linear-gradient(90deg, #173e34ed 0%, #173e34a8 62%, #173e3420 100%), url("${banner.imageUrl}")` } : undefined}>
          <div><span className="eyebrow">A LITTLE SOMETHING EXTRA</span><h2>{banner.title}</h2>{banner.description && <p>{banner.description}</p>}
            {banner.linkUrl?.startsWith("https://")
              ? <a className="button button-primary" href={banner.linkUrl} target="_blank" rel="noreferrer">Discover more <span>→</span></a>
              : <Link className="button button-primary" href={banner.linkUrl || "/shop"}>Discover more <span>→</span></Link>}
          </div><div className="promo-decoration"><span>✦</span><b>GOOD<br />THINGS<br />INSIDE</b><small>AIRO XPRESS</small></div>
        </section>)}

      {home && <section className="newsletter">
        <div><span className="eyebrow">THE GOOD LIST</span><h2>Good things, occasionally.</h2><p>New finds and little perks. No noise, we promise.</p></div>
        <form onSubmit={subscribe}><label className="sr-only" htmlFor="newsletter-email">Your email address</label><input id="newsletter-email" name="email" type="email" placeholder="Your email address" required /><button className="button button-dark">Count me in <span>→</span></button>{newsletterMessage && <small className="newsletter-message">{newsletterMessage}</small>}</form>
      </section>}
    </div>
  );
}
