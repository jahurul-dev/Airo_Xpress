"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { trackMetaEvent } from "@/lib/meta-pixel";

export type ProductSummary = {
  id: string;
  name: string;
  slug: string;
  price: string | number;
  compareAtPrice?: string | number | null;
  stock: number;
  rating?: number;
  reviewCount?: number;
  images?: { url: string; alt?: string | null }[];
  category?: { name: string };
};

export function ProductCard({ product }: { product: ProductSummary }) {
  const [message, setMessage] = useState("");
  const price = Number(product.price);
  const compare = product.compareAtPrice ? Number(product.compareAtPrice) : 0;
  const discount = compare > price ? Math.round((compare - price) / compare * 100) : 0;

  async function addToCart() {
    const response = await fetch("/api/cart", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, quantity: 1 })
    });
    if (response.status === 401) {
      window.location.href = "/login?next=/cart";
      return;
    }
    const data = await response.json();
    setMessage(response.ok ? "Added to cart" : data.error ?? "Could not add product");
    if (response.ok) {
      trackMetaEvent("AddToCart", {
        content_ids: [product.id],
        content_type: "product",
        currency: "BDT",
        value: Number(product.price)
      });
    }
    window.setTimeout(() => setMessage(""), 2400);
  }

  return (
    <article className="product-card">
      <Link className="product-image" href={`/product/${product.slug}`}>
        {discount > 0 && <span className="discount-badge">-{discount}%</span>}
        {product.images?.[0]?.url
          ? <Image src={product.images[0].url} alt={product.images[0].alt ?? product.name} fill unoptimized sizes="(max-width: 620px) 50vw, (max-width: 900px) 33vw, 25vw" />
          : <span className="image-placeholder"><span>AIRO</span><small>Everyday essentials</small></span>}
      </Link>
      <div className="product-info">
        {product.category && <span className="product-category">{product.category.name}</span>}
        <Link href={`/product/${product.slug}`} className="product-title">{product.name}</Link>
        <div className="product-rating"><span aria-label={`${product.rating ?? 0} out of 5 stars`}>★★★★★</span><small>({product.reviewCount ?? 0})</small></div>
        <div className="product-prices"><strong>৳{price.toLocaleString("en-BD")}</strong>{compare > price && <del>৳{compare.toLocaleString("en-BD")}</del>}</div>
        <button className="button button-small button-outline add-button" disabled={product.stock < 1} onClick={addToCart}>
          {product.stock < 1 ? "Out of stock" : message || "Add to cart"}
        </button>
      </div>
    </article>
  );
}
