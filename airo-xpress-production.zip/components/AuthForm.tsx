"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { getSafeReturnPath } from "@/lib/redirect";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const register = mode === "register";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = new FormData(event.currentTarget);
    const payload = {
      ...(register ? { name: form.get("name"), phone: form.get("phone") || undefined } : {}),
      email: form.get("email"), password: form.get("password")
    };
    try {
      const response = await fetch(`/api/auth/${register ? "register" : "login"}`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Could not sign in");
      const destination = params.get("next");
      router.push(getSafeReturnPath(destination, window.location.origin));
      router.refresh();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Something went wrong");
    } finally { setBusy(false); }
  }

  return <section className="auth-page"><div className="auth-card">
    <span className="eyebrow">WELCOME TO AIRO XPRESS</span><h1>{register ? "Create your account" : "Welcome back"}</h1>
    <p>{register ? "A few details and you're ready to find something good." : "Sign in to pick up right where you left off."}</p>
    <form onSubmit={submit}>
      {register && <div className="form-field"><label htmlFor="name">Full name</label><input id="name" name="name" autoComplete="name" required minLength={2} maxLength={80} /></div>}
      <div className="form-field"><label htmlFor="email">Email address</label><input id="email" name="email" type="email" autoComplete="email" required /></div>
      {register && <div className="form-field"><label htmlFor="phone">Phone number <span className="muted-copy">(optional)</span></label><input id="phone" name="phone" type="tel" autoComplete="tel" /></div>}
      <div className="form-field"><label htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete={register ? "new-password" : "current-password"} required minLength={register ? 10 : 1} maxLength={128} />{register && <small className="muted-copy">Use at least 10 characters.</small>}</div>
      {error && <div className="notice notice-error">{error}</div>}
      <button className="button button-primary" disabled={busy}>{busy ? "Please wait…" : register ? "Create account" : "Sign in"} <span>→</span></button>
    </form>
    {!register && <div className="auth-switch"><Link href="/forgot-password">Forgot your password?</Link></div>}
    <div className="auth-switch">{register ? "Already have an account?" : "New to AIRO XPRESS?"} <Link href={register ? "/login" : "/register"}>{register ? "Sign in" : "Create an account"}</Link></div>
  </div></section>;
}
