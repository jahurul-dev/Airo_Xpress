import Link from "next/link";
import Image from "next/image";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-main container">
        <div className="footer-brand">
          <Link className="brand brand-light" href="/" aria-label="AIRO XPRESS home">
            <Image className="brand-logo footer-brand-logo" src="/airo-xpress-logo.png" alt="AIRO XPRESS" width={170} height={96} />
          </Link>
          <p>Everyday finds, thoughtfully delivered. A better way to shop the things you love.</p>
        </div>
        <div><h3>Explore</h3><Link href="/shop">Shop all</Link><Link href="/shop?category=electronics">Electronics</Link><Link href="/shop?category=fashion">Fashion</Link></div>
        <div><h3>Customer care</h3><Link href="/account">My account</Link><Link href="/account/orders">Order tracking</Link><a href="mailto:jahurulislam.dev@gmail.com">jahurulislam.dev@gmail.com</a></div>
        <div><h3>Shopping in Bangladesh</h3><p>Cash on delivery available<br />Dhaka &amp; nationwide delivery<br />Support: 9am–9pm, every day</p></div>
      </div>
      <div className="footer-bottom"><div className="container">
        <span>© {new Date().getFullYear()} AIRO XPRESS. All rights reserved.</span>
        <div className="footer-links">
          <a href="https://www.facebook.com/share/1GXszD8spZ/" target="_blank" rel="noopener noreferrer">Facebook page ↗</a>
          <span>Build by JAHURUL ISLAM</span>
        </div>
      </div></div>
    </footer>
  );
}
