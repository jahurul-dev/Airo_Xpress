"use client";

import Link from "next/link";
import Image from "next/image";
import { FormEvent, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type User = { name: string; role: string } | null;

const developerEmail = "jahurulislam.dev@gmail.com";

export function SiteHeader() {
  const [query, setQuery] = useState("");
  const [user, setUser] = useState<User>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [profileImageFailed, setProfileImageFailed] = useState(false);
  const [copyMessage, setCopyMessage] = useState("");
  const mobileMenuButtonRef = useRef<HTMLButtonElement>(null);
  const aboutButtonRef = useRef<HTMLButtonElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const profileDialogRef = useRef<HTMLDialogElement>(null);
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/me").then((response) => response.json()).then((data) => setUser(data.user))
      .catch(() => setUser(null));
  }, []);

  useEffect(() => {
    const dialog = profileDialogRef.current;
    if (!aboutOpen || !dialog || dialog.open) return;

    const aboutButton = aboutButtonRef.current;
    const mobileMenuButton = mobileMenuButtonRef.current;
    dialog.showModal();
    closeButtonRef.current?.focus();
    return () => {
      if (dialog.open) dialog.close();
      if (aboutButton?.getClientRects().length) aboutButton.focus();
      else mobileMenuButton?.focus();
    };
  }, [aboutOpen]);

  function search(event: FormEvent) {
    event.preventDefault();
    router.push(`/shop${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ""}`);
    setMenuOpen(false);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/");
  }

  async function copyDeveloperEmail() {
    try {
      await navigator.clipboard.writeText(developerEmail);
      setCopyMessage("Email copied");
    } catch {
      setCopyMessage("Copy unavailable. You can select the email address instead.");
    }
  }

  function closeAbout() {
    setAboutOpen(false);
  }

  return (
    <header className="site-header">
      <div className="header-main container">
        <button ref={mobileMenuButtonRef} className="mobile-menu icon-button" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>☰</button>
        <Link className="brand" href="/" aria-label="AIRO XPRESS home">
          <Image className="brand-logo" src="/airo-xpress-logo.png" alt="AIRO XPRESS" width={170} height={96} priority />
        </Link>
        <form className="search-form" onSubmit={search}>
          <label className="sr-only" htmlFor="site-search">Search products</label>
          <input id="site-search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search products, brands and more..." />
          <button type="submit" aria-label="Search">⌕</button>
        </form>
        <nav className="header-actions" aria-label="Account and shopping">
          {user ? <><Link className="header-link" href="/account"><span className="action-icon">♙</span><span><small>Hello, {user.name.split(" ")[0]}</small><b>My account</b></span></Link>
            <button className="header-link plain-button" onClick={logout}><span className="action-icon">↪</span><span><small>Sign out</small><b>Account</b></span></button></> :
            <Link className="header-link" href="/login"><span className="action-icon">♙</span><span><small>Welcome</small><b>Sign in</b></span></Link>}
          <Link className="header-link cart-link" href="/cart"><span className="action-icon">▢</span><span><small>Ready when</small><b>Cart</b></span></Link>
        </nav>
      </div>
      <nav className={`category-nav ${menuOpen ? "is-open" : ""}`} aria-label="Product categories">
        <div className="container category-nav-inner">
          <Link href="/shop">All products</Link><Link href="/shop?category=electronics">Electronics</Link>
          <Link href="/shop?category=fashion">Fashion</Link><Link href="/shop?category=home-kitchen">Home &amp; Kitchen</Link>
          <Link href="/shop?category=beauty">Beauty</Link><Link href="/shop?category=sports">Sports</Link>
          <Link href="/shop?category=grocery">Grocery</Link><Link href="/shop?category=accessories">Accessories</Link>
          <button
            ref={aboutButtonRef}
            type="button"
            aria-haspopup="dialog"
            aria-expanded={aboutOpen}
            onClick={() => { setCopyMessage(""); setAboutOpen(true); }}
          >
            About Me
          </button>
        </div>
      </nav>
      <dialog
        ref={profileDialogRef}
        className="profile-dialog"
        aria-labelledby="developer-profile-name"
        onCancel={closeAbout}
        onKeyDown={(event) => { if (event.key === "Escape") closeAbout(); }}
        onClose={() => setAboutOpen(false)}
        onClick={(event) => { if (event.target === event.currentTarget) closeAbout(); }}
      >
        <section className="profile-card">
          <button ref={closeButtonRef} className="profile-close" type="button" aria-label="Close About Me profile" onClick={closeAbout}>
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg>
          </button>
          <div className="profile-avatar">
            {profileImageFailed ? (
              <svg className="profile-fallback" viewBox="0 0 64 64" role="img" aria-label="Developer profile placeholder">
                <circle cx="32" cy="23" r="12" />
                <path d="M10 58c1-13 9-20 22-20s21 7 22 20" />
              </svg>
            ) : (
              <Image
                src="/developer-profile.png"
                alt="Portrait of Jahurul Islam"
                width={128}
                height={128}
                sizes="128px"
                unoptimized
                onError={() => setProfileImageFailed(true)}
              />
            )}
          </div>
          <span className="eyebrow">MEET THE DEVELOPER</span>
          <h2 id="developer-profile-name">JAHURUL ISLAM</h2>
          <p className="profile-role">Full-Stack Web &amp; Mobile Application Developer</p>
          <p className="profile-bio">Passionate about building modern, fast, and user-friendly e-commerce platforms like Airo Express.</p>
          <div className="profile-contact">
            <a href={`mailto:${developerEmail}`}>{developerEmail}</a>
            <button type="button" className="profile-copy" aria-label="Copy email address" onClick={copyDeveloperEmail}>
              {copyMessage === "Email copied" ? "Copied" : "Copy"}
            </button>
          </div>
          <p className="profile-copy-message" role="status" aria-live="polite">{copyMessage}</p>
        </section>
      </dialog>
    </header>
  );
}
